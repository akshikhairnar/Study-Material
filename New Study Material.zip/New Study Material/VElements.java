package com.isg.ext.model;

import java.io.Serializable;


import javax.persistence.*;
@Entity
@Table(name="APP_VISA_DETAILS")
public class VElements implements Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 134561L;
	@Id
	@Column(name="ID")
	public String ID ;
	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	@Column(name="TCQ")
	public String tcq ;
	@Column(name="CARD_NUMBER")
	public String an ;
	@Column(name="ARN")
	public String arn ;
	@Column(name="TRAN_CODE")
	public String tc;
	@Column(name="TRAN_CODE_SEQ_NUM")
	public String tcsn;
	@Column(name="CARD_NUM_EXT")
	public String ane ;
	@Column(name="FLOOR_LMT_IND")
	public String fli ;
	@Column(name="EXCEPTION_FILE_IND")
	public String cbr ;
	@Column(name="POSITIVE_CRD_HLD_ATH_SRV_IND")
	public String pcas ;
	@Column(name="ACQ_BUSS_ID")
	public String abid;
	@Column(name="PURSHASE_DTE")
	public String purdte ;
	@Column(name="DEST_AMT")
	public String damt ;
	@Column(name="DEST_CURR_CDE")
	public String descurrcde ;
	@Column(name="SRC_AMT")
	public String samt ;
	@Column(name="SRC_CURR_CDE")
	public String sourcecurrcde ;
	@Column(name="MERCH_NME")
	public String mename ;
	@Column(name="MERCH_CITY")
	public String mecity;
	@Column(name="MERCH_CNTRY_CDE")
	public String mecntcde;
	@Column(name="MCC")
	public String mecatcode;
	@Column(name="MERCH_ZIP_CDE")
	public String mezipcde;
	@Column(name="MERCH_STATE")
	public String mestate;
	@Column(name="REQ_PAY_CDE")
	public String reqpaystate;
	@Column(name="NO_PAYMENT_FORM")
	public String numpayform;
	@Column(name="USAGE_CDE")
	public String uc;
	@Column(name="REASON_CDE")
	public String rc;
	@Column(name="SETT_FLAG")
	public String settflag;
	@Column(name="AUTH_CHAR_IND")
	public String ac1;
	@Column(name="AUTH_CDE")
	public String ac;
	@Column(name="POS_TERM_CAP")
	public String postermcap;
	@Column(name="INT_FEE_IND")
	public String intfeeInd;
	@Column(name="CARDHLD_ID_MTD")
	public String cardHoldIdmethod;
	@Column(name="COL_ONLY_FLG")
	public String collectionOnlyFlg;
	@Column(name="POS_ENTRY_MODE")
	public String posentrymode;
	@Column(name="CPD")
	public String cpd;
	@Column(name="BUSS_CDE")
	public String bussforcde;
	@Column(name="CHBK_REF_NO")
	public String chbkrefno;
	@Column(name="DOC_IND")
	public String docind;
	@Column(name="MEM_MSG_TXT")
	public String memmsgtxt;
	@Column(name="SPEC_CND_IND")
	public String spcndind;
	@Column(name="FEE_PRGM_IND")
	public String feeprgind;
	@Column(name="ISS_CHRGE")
	public String isschrge;
	@Column(name="CRD_ACCP_ID")
	public String crdaccpid;
	@Column(name="TERM_ID")
	public String terminalid;
	@Column(name="NATION_REIM_FEE")
	public String nationremfee;
	@Column(name="MAIL_ID")
	public String mailind;
	@Column(name="SPEC_CHBK_IND")
	public String specchbhind;
	@Column(name="INT_TRAN_NUM")
	public String intertranum;
	@Column(name="ACC_TERM_IND")
	public String acctermind;
	@Column(name="PREPAID_CRD_IND")
	public String perpaidcardind;
	@Column(name="AVS_RESPONSE_CDE")
	public String avsrescode;
	@Column(name="AUTH_SRC_CDE")
	public String authsourcecode;
	@Column(name="PUR_IND_FRMT")
	public String purchaseidenformat;
	@Column(name="ACCNT_SELECTION")
	public String accselection;
	@Column(name="INSTALL_PAYMENT_CNT")
	public String installpaymentcount;
	@Column(name="PUR_IND")
	public String purchaseind;
	@Column(name="CASHBACK")
	public String cashback;
	@Column(name="CHIP_COND_CDE")
	public String chipcondcode;
	@Column(name="POS_ENV")
	public String posenv;
	@Column(name="ANC_TICKET_DOC_NO")
	public String atdn;
	@Column(name="ANC_SRV_CTGRY1")
	public String asc1;
	@Column(name="ANC_SRV_SUB_CTGRY1")
	public String assc1;
	@Column(name="ANC_SRV_CTGRY2")
	public String asc2;
	@Column(name="ANC_SRV_SUB_CTGRY2")
	public String assc2;
	@Column(name="ANC_SRV_CTGRY3")
	public String asc3;
	@Column(name="ANC_SRV_SUB_CTGRY3")
	public String assc3;
	@Column(name="ANC_SRV_CTGRY4")
	public String asc4 ;
	@Column(name="ANC_SRV_SUB_CTGRY4")
	public String assc4;
	@Column(name="PASSNGER_NAME")
	public String passnme;
	@Column(name="ISSD_CONN_WTH_TCK_NO")
	public String aiicwtn;
	@Column(name="RESERVED_IND")
	public String acri;
	@Column(name="LOGD_NOSHOW_IND")
	public String lnsi;
	@Column(name="LOGD_EXT_CHGS")
	public String ulec;
	@Column(name="LOGD_CHNIN_DTE")
	public String ulcid;
	@Column(name="DAILY_ROOM_RTE")
	public String udrr;
	@Column(name="TOTAL_TAX")
	public String utt;
	@Column(name="PREPAID_EXPENSES")
	public String upe;
	@Column(name="FOOD_CHARGES")
	public String ufc;
	@Column(name="FOLIO_CASH_ADVANCES")
	public String ufca;
	@Column(name="ROOM_NIGHTS")
	public String urn;
	@Column(name="TOTAL_ROOM_TAX")
	public String utrt;
	@Column(name="DYS_RENTED")
	public String dr;
	@Column(name="CAR_RENTAL_NO_SHW_IND")
	public String crnsi;
	@Column(name="CAR_RENTAL_CHK_IN_DTE")
	public String crcid;
	@Column(name="DAILY_RENTAL_RTE")
	public String drr;
	@Column(name="WEEKLY_RNL_RTE")
	public String wrr;
	@Column(name="ISSURANCE_CHGS")
	public String ic;
	@Column(name="FUEL_CHGS")
	public String fc;
	@Column(name="CAR_CLASS_CDE")
	public String ccc;
	@Column(name="ONE_WAY_DROP_OFF_CHGS")
	public String owdoc;
	@Column(name="RENTAL_NAME")
	public String rentername;
	@Column(name="EXPD_FUEL_TYP")
	public String eft;
	@Column(name="TYP_OF_PURCHASE")
	public String top ;
	@Column(name="FUEL_TYP")
	public String ft ;
	@Column(name="UNIT_OF_MEASUREMENT")
	public String uom ;
	@Column(name="QUANTITY")
	public String uq;
	@Column(name="UNIT_COST")
	public String uuc ;
	@Column(name="GROSS_FUEL_PRICE")
	public String ugnp ;
	@Column(name="NET_FUEL_PRICE")
	public String unnp ;
	@Column(name="ODOMETER_READING")
	public String ordg ;
	@Column(name="VAT_TAX_RATE")
	public String vtr;
	@Column(name="MIS_FUEL_TAX")
	public String mft ;
	@Column(name="PDT_QLFR")
	public String pq ;
	@Column(name="MIS_NON_FUEL_TAX")
	public String mnt ;
	@Column(name="SERVICE_TYPE")
	public String servicetyp ;
	@Column(name="MIS_FEE_TAX_EXP_STATUS")
	public String mftes ;
	@Column(name="MIS_NON_TAX_EXP_SRV")
	public String mntes;
	@Column(name="CARD_TAX_ID_TYP")
	public String ctit ;
	@Column(name="CARD_TAX_ID")
	public String cti;
	@Column(name="ASST_IND")
	public String ai ;
	@Column(name="LOAN_TYP")
	public String lt ;
	@Column(name="MERCHNT_PROG_IDEN")
	public String mgi ;
	@Column(name="FAST_FUND_IDEN")
	public String ffi;
	@Column(name="BUSS_APP_ID")
	public String baid;
	@Column(name="SRC_FUND")
	public String sof;
	@Column(name="PAY_REV_RSN_CDE")
	public String prrc;
	@Column(name="SENDER_REF_NO")
	public String srn;
	@Column(name="SENDER_ACC_NO")
	public String san ;
	@Column(name="SENDER_NAME")
	public String sn ;
	@Column(name="SENDER_ADDRESS")
	public String saddr;
	@Column(name="SENDER_CITY")
	public String scity;
	@Column(name="SENDER_STATE")
	public String sstate ;
	@Column(name="SENDER_COUNTRY")
	public String scntry;
	@Column(name="NETWORK_IDEN_CODE")
	public String nic;
	@Column(name="CONTACT_INF")
	public String ci ;
	@Column(name="ADJ_PROC_IDEN")
	public String api ;
	//public String rc ;
	@Column(name="SUR_AMT")
	public String sa ;
	@Column(name="SUR_CRDR_IND")
	public String scdi ;
	@Column(name="PROMOTION_TYPE")
	public String pt ;
	@Column(name="PROMOTION_CODE")
	public String pc ;
	@Column(name="SUR_AMT_CRD_DBT")
	public String sacbc ;
	@Column(name="TRAN_IDEN")
	public String tranidentifier ;
	@Column(name="AUTH_AMT")
	public String authamt;
	@Column(name="AUTH_CURR_CDE")
	public String authcurrcde ;
	@Column(name="AUTH_RESC_CDE")
	public String authrescde;
	@Column(name="VALIDATION_CODE")
	public String validatiocde;
	@Column(name="EXC_TRAN_IDEN_RSN")
	public String exctranidnrsn ;
	@Column(name="CRC_PROC_CODE")
	public String crsprocccde;
	@Column(name="CHBK_RIGTHS_IND")
	public String chbkrgtind;
	@Column(name="MUL_CLRNG_SEQ_NUM")
	public String mulcleseqnum;
	@Column(name="MUL_CLRNG_SEQ_CNT")
	public String mulcleseqcnt;
	@Column(name="MRKT_SPEC_ATH_DATA_IND")
	public String marspecathdataind;
	@Column(name="INF_IND")
	public String infind ;
	@Column(name="MERCH_TEL_NO")
	public String mertelnum;
	@Column(name="ADD_DATA_IND")
	public String adi;
	@Column(name="MERCH_VOL_IND")
	public String mervolind;
	@Column(name="ELEC_COMM_GOODS_IND")
	public String elcommgoodsind;
	@Column(name="MERCH_VERIFICATION_VALUE")
	public String merchvervalue;
	@Column(name="INT_FEE_AMT")
	public String intfeeamt;
	@Column(name="SRC_CURR_BASE_CURR_RTE")
	public String srccurrbasecurrexcrte;
	@Column(name="BASE_CURR_DEST_CURR_RATE")
	public String basecurrdestcurrexcrte;
	@Column(name="OPT_ISS_ISA_AMT")
	public String oiia;
	@Column(name="PROD_ID")
	public String prodid;
	@Column(name="PROG_ID")
	public String progid;
	@Column(name="DCC_IND")
	public String dccind;
	@Column(name="ACCNT_TYP_IND")
	public String acctypid;
	@Column(name="SPEND_QUAL_IND")
	public String spenquind;
	@Column(name="LOCAL_TAX")
	public String unlcltx;
	@Column(name="LOCAL_TAX_INC")
	public String unlcltxinc;
	@Column(name="NATIONAL_TAX")
	public String unnattx;
	@Column(name="NATION_TAX_INC")
	public String unnattxinc;
	@Column(name="MERCH_VAT_BUSS_REF_NO")
	public String mvrbrn;
	@Column(name="CUST_VAT_REG_NO")
	public String crn;
	@Column(name="SUMM_COMODITY_CODE")
	public String scc;
	@Column(name="OTHER_TAX")
	public String othtx;
	@Column(name="MSG_IND")
	public String msgind ;
	@Column(name="CUSTOMER_CODE_REF_IND")
	public String ccri;
	@Column(name="NON_FUEL_PROD_CDE1")
	public String nfpc1;
	@Column(name="NON_FUEL_PROD_CDE2")
	public String nfpc2;
	@Column(name="NON_FUEL_PROD_CDE3")
	public String nfpc3;
	@Column(name="NON_FUEL_PROD_CDE4")
	public String nfpc4;
	@Column(name="NON_FUEL_PROD_CDE5")
	public String nfpc5;
	@Column(name="NON_FUEL_PROD_CDE6")
	public String nfpc6;
	@Column(name="NON_FUEL_PROD_CDE7")
	public String nfpc7;
	@Column(name="NON_FUEL_PROD_CDE8")
	public String nfpc8;
	@Column(name="MERCH_POSTAL_CDE")
	public String mpc;
	@Column(name="CRD_SEQ_NUM")
	public String crdseqnum;
	@Column(name="TERM_TRAN_DATE")
	public String trmtrndte;
	@Column(name="TERM_CAPABILITY_PROFILE")
	public String trmcapprf;
	@Column(name="TERM_COUNTRY_CODE")
	public String trmcntcde;
	@Column(name="TERM_SER_NUM")
	public String trmsernum;
	@Column(name="UNPRED_NO")
	public String unprenum;
	@Column(name="APP_TRAN_CNT")
	public String apptrancnt;
	@Column(name="APP_INTCHG_CNT")
	public String appintchgcnt;
	@Column(name="CRYTO")
	public String crypto; 
	@Column(name="ISS_APP_DATA1")
	public String issappdata1;
	@Column(name="ISS_APP_DATA2")
	public String issappdata2;
	@Column(name="TERM_VER_RES")
	public String termverres;
	@Column(name="ISS_APP_DATA3")
	public String issappdata3;
	@Column(name="ISS_APP_DATA4")
	public String issappdata4;
	@Column(name="ISS_APP_DATA5")
	public String issappdata5;
	@Column(name="ISS_APP_DATA6")
	public String issappdata6;
	@Column(name="ISS_APP_DATA7")
	public String issappdata7;
	@Column(name="ISS_APP_DATA8")
	public String issappdata8;
	@Column(name="TOT_AUTH_AMT")
	public String totauthamt ;
	@Column(name="INT_FEE_SIGN")
	public String intfeesign;
	@Column(name="PROCESS_ID")
	public String process_id;
	@Transient
	public String txntyp;
	@Transient
	public String cryptamt;
	@Transient
	public String formfactor;
	public String getTxntyp() {
		return txntyp;
	}

	public void setTxntyp(String txntyp) {
		this.txntyp = txntyp;
	}

	public String getProcess_id() {
		return process_id;
	}

	public void setProcess_id(String process_id) {
		this.process_id = process_id;
	}

	public String getIntfeesign() {
		return intfeesign;
	}

	public void setIntfeesign(String intfeesign) {
		this.intfeesign = intfeesign;
	}

	public String getTotauthamt() {
		return totauthamt;
	}

	public void setTotauthamt(String totauthamt) {
		this.totauthamt = totauthamt;
	}

	public String getTcq() {
		return tcq;
	}

	public void setTcq(String tcq) {
		this.tcq = tcq;
	}

	public String getAn() {
		return an;
	}

	public void setAn(String an) {
		this.an = an;
	}

	public String getArn() {
		return arn;
	}

	public void setArn(String arn) {
		this.arn = arn;
	}

	public String getTc() {
		return tc;
	}

	public void setTc(String tc) {
		this.tc = tc;
	}

	public String getTcsn() {
		return tcsn;
	}

	public void setTcsn(String tcsn) {
		this.tcsn = tcsn;
	}

	public String getAne() {
		return ane;
	}

	public void setAne(String ane) {
		this.ane = ane;
	}

	public String getFli() {
		return fli;
	}

	public void setFli(String fli) {
		this.fli = fli;
	}

	public String getCbr() {
		return cbr;
	}

	public void setCbr(String cbr) {
		this.cbr = cbr;
	}

	public String getPcas() {
		return pcas;
	}

	public void setPcas(String pcas) {
		this.pcas = pcas;
	}

	public String getAbid() {
		return abid;
	}

	public void setAbid(String abid) {
		this.abid = abid;
	}

	public String getPurdte() {
		return purdte;
	}

	public void setPurdte(String purdte) {
		this.purdte = purdte;
	}

	public String getDamt() {
		return damt;
	}

	public void setDamt(String damt) {
		this.damt = damt;
	}

	public String getDescurrcde() {
		return descurrcde;
	}

	public void setDescurrcde(String descurrcde) {
		this.descurrcde = descurrcde;
	}

	public String getSamt() {
		return samt;
	}

	public void setSamt(String samt) {
		this.samt = samt;
	}

	public String getSourcecurrcde() {
		return sourcecurrcde;
	}

	public void setSourcecurrcde(String sourcecurrcde) {
		this.sourcecurrcde = sourcecurrcde;
	}

	public String getMename() {
		return mename;
	}

	public void setMename(String mename) {
		this.mename = mename;
	}

	public String getMecity() {
		return mecity;
	}

	public void setMecity(String mecity) {
		this.mecity = mecity;
	}

	public String getMecntcde() {
		return mecntcde;
	}

	public void setMecntcde(String mecntcde) {
		this.mecntcde = mecntcde;
	}

	public String getMecatcode() {
		return mecatcode;
	}

	public void setMecatcode(String mecatcode) {
		this.mecatcode = mecatcode;
	}

	public String getMezipcde() {
		return mezipcde;
	}

	public void setMezipcde(String mezipcde) {
		this.mezipcde = mezipcde;
	}

	public String getMestate() {
		return mestate;
	}

	public void setMestate(String mestate) {
		this.mestate = mestate;
	}

	public String getReqpaystate() {
		return reqpaystate;
	}

	public void setReqpaystate(String reqpaystate) {
		this.reqpaystate = reqpaystate;
	}

	public String getNumpayform() {
		return numpayform;
	}

	public void setNumpayform(String numpayform) {
		this.numpayform = numpayform;
	}

	public String getUc() {
		return uc;
	}

	public void setUc(String uc) {
		this.uc = uc;
	}

	public String getRc() {
		return rc;
	}

	public void setRc(String rc) {
		this.rc = rc;
	}

	public String getSettflag() {
		return settflag;
	}

	public void setSettflag(String settflag) {
		this.settflag = settflag;
	}

	public String getAc1() {
		return ac1;
	}

	public void setAc1(String ac1) {
		this.ac1 = ac1;
	}

	public String getAc() {
		return ac;
	}

	public void setAc(String ac) {
		this.ac = ac;
	}

	public String getPostermcap() {
		return postermcap;
	}

	public void setPostermcap(String postermcap) {
		this.postermcap = postermcap;
	}

	public String getIntfeeInd() {
		return intfeeInd;
	}

	public void setIntfeeInd(String intfeeInd) {
		this.intfeeInd = intfeeInd;
	}

	public String getCardHoldIdmethod() {
		return cardHoldIdmethod;
	}

	public void setCardHoldIdmethod(String cardHoldIdmethod) {
		this.cardHoldIdmethod = cardHoldIdmethod;
	}

	public String getCollectionOnlyFlg() {
		return collectionOnlyFlg;
	}

	public void setCollectionOnlyFlg(String collectionOnlyFlg) {
		this.collectionOnlyFlg = collectionOnlyFlg;
	}

	public String getPosentrymode() {
		return posentrymode;
	}

	public void setPosentrymode(String posentrymode) {
		this.posentrymode = posentrymode;
	}

	public String getCpd() {
		return cpd;
	}

	public void setCpd(String cpd) {
		this.cpd = cpd;
	}

	public String getBussforcde() {
		return bussforcde;
	}

	public void setBussforcde(String bussforcde) {
		this.bussforcde = bussforcde;
	}

	public String getChbkrefno() {
		return chbkrefno;
	}

	public void setChbkrefno(String chbkrefno) {
		this.chbkrefno = chbkrefno;
	}

	public String getDocind() {
		return docind;
	}

	public void setDocind(String docind) {
		this.docind = docind;
	}

	public String getMemmsgtxt() {
		return memmsgtxt;
	}

	public void setMemmsgtxt(String memmsgtxt) {
		this.memmsgtxt = memmsgtxt;
	}

	public String getSpcndind() {
		return spcndind;
	}

	public void setSpcndind(String spcndind) {
		this.spcndind = spcndind;
	}

	public String getFeeprgind() {
		return feeprgind;
	}

	public void setFeeprgind(String feeprgind) {
		this.feeprgind = feeprgind;
	}

	public String getIsschrge() {
		return isschrge;
	}

	public void setIsschrge(String isschrge) {
		this.isschrge = isschrge;
	}

	public String getCrdaccpid() {
		return crdaccpid;
	}

	public void setCrdaccpid(String crdaccpid) {
		this.crdaccpid = crdaccpid;
	}

	public String getTerminalid() {
		return terminalid;
	}

	public void setTerminalid(String terminalid) {
		this.terminalid = terminalid;
	}

	public String getNationremfee() {
		return nationremfee;
	}

	public void setNationremfee(String nationremfee) {
		this.nationremfee = nationremfee;
	}

	public String getMailind() {
		return mailind;
	}

	public void setMailind(String mailind) {
		this.mailind = mailind;
	}

	public String getSpecchbhind() {
		return specchbhind;
	}

	public void setSpecchbhind(String specchbhind) {
		this.specchbhind = specchbhind;
	}

	public String getIntertranum() {
		return intertranum;
	}

	public void setIntertranum(String intertranum) {
		this.intertranum = intertranum;
	}

	public String getAcctermind() {
		return acctermind;
	}

	public void setAcctermind(String acctermind) {
		this.acctermind = acctermind;
	}

	public String getPerpaidcardind() {
		return perpaidcardind;
	}

	public void setPerpaidcardind(String perpaidcardind) {
		this.perpaidcardind = perpaidcardind;
	}

	public String getAvsrescode() {
		return avsrescode;
	}

	public void setAvsrescode(String avsrescode) {
		this.avsrescode = avsrescode;
	}

	public String getAuthsourcecode() {
		return authsourcecode;
	}

	public void setAuthsourcecode(String authsourcecode) {
		this.authsourcecode = authsourcecode;
	}

	public String getPurchaseidenformat() {
		return purchaseidenformat;
	}

	public void setPurchaseidenformat(String purchaseidenformat) {
		this.purchaseidenformat = purchaseidenformat;
	}

	public String getAccselection() {
		return accselection;
	}

	public void setAccselection(String accselection) {
		this.accselection = accselection;
	}

	public String getInstallpaymentcount() {
		return installpaymentcount;
	}

	public void setInstallpaymentcount(String installpaymentcount) {
		this.installpaymentcount = installpaymentcount;
	}

	public String getPurchaseind() {
		return purchaseind;
	}

	public void setPurchaseind(String purchaseind) {
		this.purchaseind = purchaseind;
	}

	public String getCashback() {
		return cashback;
	}

	public void setCashback(String cashback) {
		this.cashback = cashback;
	}

	public String getChipcondcode() {
		return chipcondcode;
	}

	public void setChipcondcode(String chipcondcode) {
		this.chipcondcode = chipcondcode;
	}

	public String getPosenv() {
		return posenv;
	}

	public void setPosenv(String posenv) {
		this.posenv = posenv;
	}

	public String getAtdn() {
		return atdn;
	}

	public void setAtdn(String atdn) {
		this.atdn = atdn;
	}

	public String getAsc1() {
		return asc1;
	}

	public void setAsc1(String asc1) {
		this.asc1 = asc1;
	}

	public String getAssc1() {
		return assc1;
	}

	public void setAssc1(String assc1) {
		this.assc1 = assc1;
	}

	public String getAsc2() {
		return asc2;
	}

	public void setAsc2(String asc2) {
		this.asc2 = asc2;
	}

	public String getAssc2() {
		return assc2;
	}

	public void setAssc2(String assc2) {
		this.assc2 = assc2;
	}

	public String getAsc3() {
		return asc3;
	}

	public void setAsc3(String asc3) {
		this.asc3 = asc3;
	}

	public String getAssc3() {
		return assc3;
	}

	public void setAssc3(String assc3) {
		this.assc3 = assc3;
	}

	public String getAsc4() {
		return asc4;
	}

	public void setAsc4(String asc4) {
		this.asc4 = asc4;
	}

	public String getAssc4() {
		return assc4;
	}

	public void setAssc4(String assc4) {
		this.assc4 = assc4;
	}

	public String getPassnme() {
		return passnme;
	}

	public void setPassnme(String passnme) {
		this.passnme = passnme;
	}

	public String getAiicwtn() {
		return aiicwtn;
	}

	public void setAiicwtn(String aiicwtn) {
		this.aiicwtn = aiicwtn;
	}

	public String getAcri() {
		return acri;
	}

	public void setAcri(String acri) {
		this.acri = acri;
	}

	public String getLnsi() {
		return lnsi;
	}

	public void setLnsi(String lnsi) {
		this.lnsi = lnsi;
	}

	public String getUlec() {
		return ulec;
	}

	public void setUlec(String ulec) {
		this.ulec = ulec;
	}

	public String getUlcid() {
		return ulcid;
	}

	public void setUlcid(String ulcid) {
		this.ulcid = ulcid;
	}

	public String getUdrr() {
		return udrr;
	}

	public void setUdrr(String udrr) {
		this.udrr = udrr;
	}

	public String getUtt() {
		return utt;
	}

	public void setUtt(String utt) {
		this.utt = utt;
	}

	public String getUpe() {
		return upe;
	}

	public void setUpe(String upe) {
		this.upe = upe;
	}

	public String getUfc() {
		return ufc;
	}

	public void setUfc(String ufc) {
		this.ufc = ufc;
	}

	public String getUfca() {
		return ufca;
	}

	public void setUfca(String ufca) {
		this.ufca = ufca;
	}

	public String getUrn() {
		return urn;
	}

	public void setUrn(String urn) {
		this.urn = urn;
	}

	public String getUtrt() {
		return utrt;
	}

	public void setUtrt(String utrt) {
		this.utrt = utrt;
	}

	public String getDr() {
		return dr;
	}

	public void setDr(String dr) {
		this.dr = dr;
	}

	public String getCrnsi() {
		return crnsi;
	}

	public void setCrnsi(String crnsi) {
		this.crnsi = crnsi;
	}

	public String getCrcid() {
		return crcid;
	}

	public void setCrcid(String crcid) {
		this.crcid = crcid;
	}

	public String getDrr() {
		return drr;
	}

	public void setDrr(String drr) {
		this.drr = drr;
	}

	public String getWrr() {
		return wrr;
	}

	public void setWrr(String wrr) {
		this.wrr = wrr;
	}

	public String getIc() {
		return ic;
	}

	public void setIc(String ic) {
		this.ic = ic;
	}

	public String getFc() {
		return fc;
	}

	public void setFc(String fc) {
		this.fc = fc;
	}

	public String getCcc() {
		return ccc;
	}

	public void setCcc(String ccc) {
		this.ccc = ccc;
	}

	public String getOwdoc() {
		return owdoc;
	}

	public void setOwdoc(String owdoc) {
		this.owdoc = owdoc;
	}

	public String getRentername() {
		return rentername;
	}

	public void setRentername(String rentername) {
		this.rentername = rentername;
	}

	public String getEft() {
		return eft;
	}

	public void setEft(String eft) {
		this.eft = eft;
	}

	public String getTop() {
		return top;
	}

	public void setTop(String top) {
		this.top = top;
	}

	public String getFt() {
		return ft;
	}

	public void setFt(String ft) {
		this.ft = ft;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getUq() {
		return uq;
	}

	public void setUq(String uq) {
		this.uq = uq;
	}

	public String getUuc() {
		return uuc;
	}

	public void setUuc(String uuc) {
		this.uuc = uuc;
	}

	public String getUgnp() {
		return ugnp;
	}

	public void setUgnp(String ugnp) {
		this.ugnp = ugnp;
	}

	public String getUnnp() {
		return unnp;
	}

	public void setUnnp(String unnp) {
		this.unnp = unnp;
	}

	public String getOrdg() {
		return ordg;
	}

	public void setOrdg(String ordg) {
		this.ordg = ordg;
	}

	public String getVtr() {
		return vtr;
	}

	public void setVtr(String vtr) {
		this.vtr = vtr;
	}

	public String getMft() {
		return mft;
	}

	public void setMft(String mft) {
		this.mft = mft;
	}

	public String getPq() {
		return pq;
	}

	public void setPq(String pq) {
		this.pq = pq;
	}

	public String getMnt() {
		return mnt;
	}

	public void setMnt(String mnt) {
		this.mnt = mnt;
	}

	public String getServicetyp() {
		return servicetyp;
	}

	public void setServicetyp(String servicetyp) {
		this.servicetyp = servicetyp;
	}

	public String getMftes() {
		return mftes;
	}

	public void setMftes(String mftes) {
		this.mftes = mftes;
	}

	public String getMntes() {
		return mntes;
	}

	public void setMntes(String mntes) {
		this.mntes = mntes;
	}

	public String getCtit() {
		return ctit;
	}

	public void setCtit(String ctit) {
		this.ctit = ctit;
	}

	public String getCti() {
		return cti;
	}

	public void setCti(String cti) {
		this.cti = cti;
	}

	public String getAi() {
		return ai;
	}

	public void setAi(String ai) {
		this.ai = ai;
	}

	public String getLt() {
		return lt;
	}

	public void setLt(String lt) {
		this.lt = lt;
	}

	public String getMgi() {
		return mgi;
	}

	public void setMgi(String mgi) {
		this.mgi = mgi;
	}

	public String getFfi() {
		return ffi;
	}

	public void setFfi(String ffi) {
		this.ffi = ffi;
	}

	public String getBaid() {
		return baid;
	}

	public void setBaid(String baid) {
		this.baid = baid;
	}

	public String getSof() {
		return sof;
	}

	public void setSof(String sof) {
		this.sof = sof;
	}

	public String getPrrc() {
		return prrc;
	}

	public void setPrrc(String prrc) {
		this.prrc = prrc;
	}

	public String getSrn() {
		return srn;
	}

	public void setSrn(String srn) {
		this.srn = srn;
	}

	public String getSan() {
		return san;
	}

	public void setSan(String san) {
		this.san = san;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getSaddr() {
		return saddr;
	}

	public void setSaddr(String saddr) {
		this.saddr = saddr;
	}

	public String getScity() {
		return scity;
	}

	public void setScity(String scity) {
		this.scity = scity;
	}

	public String getSstate() {
		return sstate;
	}

	public void setSstate(String sstate) {
		this.sstate = sstate;
	}

	public String getScntry() {
		return scntry;
	}

	public void setScntry(String scntry) {
		this.scntry = scntry;
	}

	public String getNic() {
		return nic;
	}

	public void setNic(String nic) {
		this.nic = nic;
	}

	public String getCi() {
		return ci;
	}

	public void setCi(String ci) {
		this.ci = ci;
	}

	public String getApi() {
		return api;
	}

	public void setApi(String api) {
		this.api = api;
	}

	public String getSa() {
		return sa;
	}

	public void setSa(String sa) {
		this.sa = sa;
	}

	public String getScdi() {
		return scdi;
	}

	public void setScdi(String scdi) {
		this.scdi = scdi;
	}

	public String getPt() {
		return pt;
	}

	public void setPt(String pt) {
		this.pt = pt;
	}

	public String getPc() {
		return pc;
	}

	public void setPc(String pc) {
		this.pc = pc;
	}

	public String getSacbc() {
		return sacbc;
	}

	public void setSacbc(String sacbc) {
		this.sacbc = sacbc;
	}

	public String getTranidentifier() {
		return tranidentifier;
	}

	public void setTranidentifier(String tranidentifier) {
		this.tranidentifier = tranidentifier;
	}

	public String getAuthamt() {
		return authamt;
	}

	public void setAuthamt(String authamt) {
		this.authamt = authamt;
	}

	public String getAuthcurrcde() {
		return authcurrcde;
	}

	public void setAuthcurrcde(String authcurrcde) {
		this.authcurrcde = authcurrcde;
	}

	public String getAuthrescde() {
		return authrescde;
	}

	public void setAuthrescde(String authrescde) {
		this.authrescde = authrescde;
	}

	public String getValidatiocde() {
		return validatiocde;
	}

	public void setValidatiocde(String validatiocde) {
		this.validatiocde = validatiocde;
	}

	public String getExctranidnrsn() {
		return exctranidnrsn;
	}

	public void setExctranidnrsn(String exctranidnrsn) {
		this.exctranidnrsn = exctranidnrsn;
	}

	public String getCrsprocccde() {
		return crsprocccde;
	}

	public void setCrsprocccde(String crsprocccde) {
		this.crsprocccde = crsprocccde;
	}

	public String getChbkrgtind() {
		return chbkrgtind;
	}

	public void setChbkrgtind(String chbkrgtind) {
		this.chbkrgtind = chbkrgtind;
	}

	public String getMulcleseqnum() {
		return mulcleseqnum;
	}

	public void setMulcleseqnum(String mulcleseqnum) {
		this.mulcleseqnum = mulcleseqnum;
	}

	public String getMulcleseqcnt() {
		return mulcleseqcnt;
	}

	public void setMulcleseqcnt(String mulcleseqcnt) {
		this.mulcleseqcnt = mulcleseqcnt;
	}

	public String getMarspecathdataind() {
		return marspecathdataind;
	}

	public void setMarspecathdataind(String marspecathdataind) {
		this.marspecathdataind = marspecathdataind;
	}

	public String getInfind() {
		return infind;
	}

	public void setInfind(String infind) {
		this.infind = infind;
	}

	public String getMertelnum() {
		return mertelnum;
	}

	public void setMertelnum(String mertelnum) {
		this.mertelnum = mertelnum;
	}

	public String getAdi() {
		return adi;
	}

	public void setAdi(String adi) {
		this.adi = adi;
	}

	public String getMervolind() {
		return mervolind;
	}

	public void setMervolind(String mervolind) {
		this.mervolind = mervolind;
	}

	public String getElcommgoodsind() {
		return elcommgoodsind;
	}

	public void setElcommgoodsind(String elcommgoodsind) {
		this.elcommgoodsind = elcommgoodsind;
	}

	public String getMerchvervalue() {
		return merchvervalue;
	}

	public void setMerchvervalue(String merchvervalue) {
		this.merchvervalue = merchvervalue;
	}

	public String getIntfeeamt() {
		return intfeeamt;
	}

	public void setIntfeeamt(String intfeeamt) {
		this.intfeeamt = intfeeamt;
	}

	public String getSrccurrbasecurrexcrte() {
		return srccurrbasecurrexcrte;
	}

	public void setSrccurrbasecurrexcrte(String srccurrbasecurrexcrte) {
		this.srccurrbasecurrexcrte = srccurrbasecurrexcrte;
	}

	public String getBasecurrdestcurrexcrte() {
		return basecurrdestcurrexcrte;
	}

	public void setBasecurrdestcurrexcrte(String basecurrdestcurrexcrte) {
		this.basecurrdestcurrexcrte = basecurrdestcurrexcrte;
	}

	public String getOiia() {
		return oiia;
	}

	public void setOiia(String oiia) {
		this.oiia = oiia;
	}

	public String getProdid() {
		return prodid;
	}

	public void setProdid(String prodid) {
		this.prodid = prodid;
	}

	public String getProgid() {
		return progid;
	}

	public void setProgid(String progid) {
		this.progid = progid;
	}

	public String getDccind() {
		return dccind;
	}

	public void setDccind(String dccind) {
		this.dccind = dccind;
	}

	public String getAcctypid() {
		return acctypid;
	}

	public void setAcctypid(String acctypid) {
		this.acctypid = acctypid;
	}

	public String getSpenquind() {
		return spenquind;
	}

	public void setSpenquind(String spenquind) {
		this.spenquind = spenquind;
	}

	public String getUnlcltx() {
		return unlcltx;
	}

	public void setUnlcltx(String unlcltx) {
		this.unlcltx = unlcltx;
	}

	public String getUnlcltxinc() {
		return unlcltxinc;
	}

	public void setUnlcltxinc(String unlcltxinc) {
		this.unlcltxinc = unlcltxinc;
	}

	public String getUnnattx() {
		return unnattx;
	}

	public void setUnnattx(String unnattx) {
		this.unnattx = unnattx;
	}

	public String getUnnattxinc() {
		return unnattxinc;
	}

	public void setUnnattxinc(String unnattxinc) {
		this.unnattxinc = unnattxinc;
	}

	public String getMvrbrn() {
		return mvrbrn;
	}

	public void setMvrbrn(String mvrbrn) {
		this.mvrbrn = mvrbrn;
	}

	public String getCrn() {
		return crn;
	}

	public void setCrn(String crn) {
		this.crn = crn;
	}

	public String getScc() {
		return scc;
	}

	public void setScc(String scc) {
		this.scc = scc;
	}

	public String getOthtx() {
		return othtx;
	}

	public void setOthtx(String othtx) {
		this.othtx = othtx;
	}

	public String getMsgind() {
		return msgind;
	}

	public void setMsgind(String msgind) {
		this.msgind = msgind;
	}

	public String getCcri() {
		return ccri;
	}

	public void setCcri(String ccri) {
		this.ccri = ccri;
	}

	public String getNfpc1() {
		return nfpc1;
	}

	public void setNfpc1(String nfpc1) {
		this.nfpc1 = nfpc1;
	}

	public String getNfpc2() {
		return nfpc2;
	}

	public void setNfpc2(String nfpc2) {
		this.nfpc2 = nfpc2;
	}

	public String getNfpc3() {
		return nfpc3;
	}

	public void setNfpc3(String nfpc3) {
		this.nfpc3 = nfpc3;
	}

	public String getNfpc4() {
		return nfpc4;
	}

	public void setNfpc4(String nfpc4) {
		this.nfpc4 = nfpc4;
	}

	public String getNfpc5() {
		return nfpc5;
	}

	public void setNfpc5(String nfpc5) {
		this.nfpc5 = nfpc5;
	}

	public String getNfpc6() {
		return nfpc6;
	}

	public void setNfpc6(String nfpc6) {
		this.nfpc6 = nfpc6;
	}

	public String getNfpc7() {
		return nfpc7;
	}

	public void setNfpc7(String nfpc7) {
		this.nfpc7 = nfpc7;
	}

	public String getNfpc8() {
		return nfpc8;
	}

	public void setNfpc8(String nfpc8) {
		this.nfpc8 = nfpc8;
	}

	public String getMpc() {
		return mpc;
	}

	public void setMpc(String mpc) {
		this.mpc = mpc;
	}

	public String getCrdseqnum() {
		return crdseqnum;
	}

	public void setCrdseqnum(String crdseqnum) {
		this.crdseqnum = crdseqnum;
	}

	public String getTrmtrndte() {
		return trmtrndte;
	}

	public void setTrmtrndte(String trmtrndte) {
		this.trmtrndte = trmtrndte;
	}

	public String getTrmcapprf() {
		return trmcapprf;
	}

	public void setTrmcapprf(String trmcapprf) {
		this.trmcapprf = trmcapprf;
	}

	public String getTrmcntcde() {
		return trmcntcde;
	}

	public void setTrmcntcde(String trmcntcde) {
		this.trmcntcde = trmcntcde;
	}

	public String getTrmsernum() {
		return trmsernum;
	}

	public void setTrmsernum(String trmsernum) {
		this.trmsernum = trmsernum;
	}

	public String getUnprenum() {
		return unprenum;
	}

	public void setUnprenum(String unprenum) {
		this.unprenum = unprenum;
	}

	public String getApptrancnt() {
		return apptrancnt;
	}

	public void setApptrancnt(String apptrancnt) {
		this.apptrancnt = apptrancnt;
	}

	public String getAppintchgcnt() {
		return appintchgcnt;
	}

	public void setAppintchgcnt(String appintchgcnt) {
		this.appintchgcnt = appintchgcnt;
	}

	public String getCrypto() {
		return crypto;
	}

	public void setCrypto(String crypto) {
		this.crypto = crypto;
	}

	public String getIssappdata1() {
		return issappdata1;
	}

	public void setIssappdata1(String issappdata1) {
		this.issappdata1 = issappdata1;
	}

	public String getIssappdata2() {
		return issappdata2;
	}

	public void setIssappdata2(String issappdata2) {
		this.issappdata2 = issappdata2;
	}

	public String getTermverres() {
		return termverres;
	}

	public void setTermverres(String termverres) {
		this.termverres = termverres;
	}

	public String getIssappdata3() {
		return issappdata3;
	}

	public void setIssappdata3(String issappdata3) {
		this.issappdata3 = issappdata3;
	}

	public String getIssappdata4() {
		return issappdata4;
	}

	public void setIssappdata4(String issappdata4) {
		this.issappdata4 = issappdata4;
	}

	public String getIssappdata5() {
		return issappdata5;
	}

	public void setIssappdata5(String issappdata5) {
		this.issappdata5 = issappdata5;
	}

	public String getIssappdata6() {
		return issappdata6;
	}

	public void setIssappdata6(String issappdata6) {
		this.issappdata6 = issappdata6;
	}

	public String getIssappdata7() {
		return issappdata7;
	}

	public void setIssappdata7(String issappdata7) {
		this.issappdata7 = issappdata7;
	}

	public String getIssappdata8() {
		return issappdata8;
	}

	public void setIssappdata8(String issappdata8) {
		this.issappdata8 = issappdata8;
	}
	
	
	
}
