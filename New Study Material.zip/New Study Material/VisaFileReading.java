package com.isg.execute;

import java.io.IOException;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;



import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;

import org.apache.spark.api.java.function.VoidFunction;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;


import org.hibernate.cfg.*;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;

import com.isg.ext.model.FileInfoDta;
import com.isg.ext.model.PMasterData;
import com.isg.ext.model.VElements;
import com.isg.ext.service.Processing_SER;
import com.isg.ext.config.VisaCnTcrCn;
public class VisaFileReading {
	
	static final String process_code = "VISAIN";
	static final String file_code = "FL0003";
	static final String product_code = "V2.0.0002";
	
	
	static String total_count ;
	static String total_amount ;
	static Date file_date;
	
	String[] nmList = {"05","06","07","01","02","03","15","16","17","25","26","27","35","36","37"};
	
	
	List<String> cmnTcrList = Arrays.asList(nmList);
	
	

	static VElements velemtemp = new VElements();
	
	static VisaCnTcrCn x = new VisaCnTcrCn();
	static int vcount = 0;
	static Session session ;
	public static void main(String[] args) throws Exception
	{
		String hadoopDir = args[1];
		String sPath = args[0];
		velemtemp.setID(String.valueOf(Math.random()));
		PMasterData pmdta = new PMasterData();
		pmdta.setProcess_id(String.valueOf(Math.random()));
		pmdta.setProcess_code(process_code);
		pmdta.setFile_code(file_code);
		pmdta.setProduct_code(product_code);
		pmdta.setStarttime(new Date());
		pmdta.setComplete("N");
		
		
		velemtemp.setProcess_id(pmdta.getProcess_id());
		
		   SparkConf conf = new SparkConf().setMaster("local").setAppName("Work Count App");
			///conf.setLogLevel("ERROR");
			System.setProperty("hadoop.home.dir", hadoopDir); 
			JavaSparkContext sc = new JavaSparkContext(conf);
			sc.setLogLevel("Error");
			System.out.println("The Start"+new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()));
			//JavaRDD<String> lines = sc.textFile("F:\\Users\\nitin1733\\Pooja_workspace_HDFC\\INCDC170425.001.TXT");
			JavaRDD<String> lines = sc.textFile(sPath);
		   
		 
		   
		   
		   List<VElements> velemList = new ArrayList<VElements>();
		   
		  
		   
		   
		   JavaRDD<VElements> flatMap = lines.flatMap(new FlatMapFunction<String, VElements>() {
				
				/**
			 * 
			 */
			private static final long serialVersionUID = 13452334L;

				@Override
				public Iterator<VElements> call(String s) throws Exception {
					
		   
						List<VElements> alist = new LinkedList<VElements>();
					//System.out.println("Adding in Listss::"+velemtemp.an);
		
						if ("92".equals(s.substring(0,2)) )
						{
							alist = new LinkedList<VElements>(velemList);
							velemList.clear();
							//System.out.println("Adding in List::"+velemtemp.arn);
						
							velemList.add(velemtemp);
							
							velemtemp = new VElements();
							velemtemp.setID(String.valueOf(Math.random()));
							velemtemp.setProcess_id(pmdta.getProcess_id());
							
							total_count = s.substring(75,83);
							total_amount = s.substring(16,30) ;
							
							String s1 = new SimpleDateFormat("yy").format(new Date());
							 int d = Integer.parseInt(s1);
							 int d1 = Integer.parseInt(s1.substring(0,1));
							 int s2 = Integer.parseInt(d1+s.substring(11, 12));
						
							if(s2>d)
								s2 = Integer.parseInt((d1-1)+s.substring(11, 12));
							
							DecimalFormat nf = new DecimalFormat("00");
							
							
							file_date = new SimpleDateFormat("yyDDD").parse(nf.format(s2)+s.substring(12, 15));
							
						
							
							return velemList.iterator();
						}
						
					if("00".equals(s.substring(2,4)) && velemtemp.getTc()!=null && "05".equals(s.substring(0,2)))
						{
						alist = new LinkedList<VElements>(velemList);
						velemList.clear();
						//System.out.println("Adding in List::"+velemtemp.arn);
					
						velemList.add(velemtemp);
						
						velemtemp = new VElements();
						velemtemp.setID(String.valueOf(Math.random()));
						velemtemp.setProcess_id(pmdta.getProcess_id());
						//return velemList.iterator();
						}else if("00".equals(s.substring(2,4)) && velemtemp.getTc()!=null && "06".equals(s.substring(0,2)))
						{
							alist = new LinkedList<VElements>(velemList);
						velemList.clear();
						//System.out.println("Adding in List::"+velemtemp.arn);
					
						velemList.add(velemtemp);
						
						velemtemp = new VElements();
						velemtemp.setID(String.valueOf(Math.random()));
						velemtemp.setProcess_id(pmdta.getProcess_id());
						//return velemList.iterator();
						}else if("00".equals(s.substring(2,4)) && velemtemp.getTc()!=null && "07".equals(s.substring(0,2)))
						{
							alist = new LinkedList<VElements>(velemList);
						velemList.clear();
						//System.out.println("Adding in List::"+velemtemp.arn);
					
						velemList.add(velemtemp);
						
						velemtemp = new VElements();
						velemtemp.setID(String.valueOf(Math.random()));
						velemtemp.setProcess_id(pmdta.getProcess_id());
						//return velemList.iterator();
						}
		
			   if(s.substring(0,2).equals("05") || s.substring(0,2).equals("07") || s.substring(0,2).equals("06"))
			   {
				   
				 //  System.out.println(s.substring(2,4));
				   if("00".equals(s.substring(2, 4)))
				   {
					   
					  Map<String, String> v =  x.getTcr_tc5_0();
					
					   
					   Class<?> clazz = velemtemp.getClass();   
					   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
					   
					   while(entry.hasNext())
					   {
						  Entry<String,String> e = entry.next();
						 
						  int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
						  int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
						  String g = s.substring(a1-1, a2);
					//	  System.out.println(e.getKey()+"-"+g);
						
						  Field f1 = clazz.getDeclaredField(e.getKey());
                		  f1.setAccessible(true);
                		  f1.set(velemtemp, g);
							
					   }
				   }
				   
				   if(s.substring(0,2).equals("05") || s.substring(0,2).equals("07") || s.substring(0,2).equals("06"))
				   {
					//   System.out.println(s.substring(2,4));
					   
					   if("00".equals(s.substring(2, 4)))
					   {
						 
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_0();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();
							  //System.out.println(e.getValue());
							//System.out.println(e.getValue().substring(0,e.getValue().indexOf(",")));
							//System.out.println(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
						   }
					   }
					   
					   if("01".equals(s.substring(2, 4)))
					   {
						  
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_1();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();
						
							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
						   }
					   }
					   if("03".equals(s.substring(2, 4)) && "AI".equals(s.substring(2, 4)))
					   {
						   
						   
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_3_AI();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();
							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("03".equals(s.substring(2, 4)) && "AN".equals(s.substring(2, 4)))
					   {
						 
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_3_AN();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();
							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("03".equals(s.substring(2, 4)) && "LG".equals(s.substring(2, 4)))
					   {
						 
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_3_LG();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();
							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("03".equals(s.substring(2, 4)) && "CA".equals(s.substring(2, 4)))
					   {
						 
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_3_CA();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();

							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
						//	System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("03".equals(s.substring(2, 4)) && "FL".equals(s.substring(2, 4)))
					   {
						
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_3_FL();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();

							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
						//	System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("03".equals(s.substring(2, 4)) && "LD".equals(s.substring(2, 4)))
					   {
						
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_3_LD();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();
							  //System.out.println(e.getValue());
							//System.out.println(e.getValue().substring(0,e.getValue().indexOf(",")));
							//System.out.println(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("03".equals(s.substring(2, 4)) && "CR".equals(s.substring(2, 4)))
					   {
						
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_3_CR();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();
							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("04".equals(s.substring(2, 4)) && "SP".equals(s.substring(2, 4)))
					   {
						 
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_4_SP();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();

							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("04".equals(s.substring(2, 4)) && "PD".equals(s.substring(2, 4)))
					   {
						  
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_3_AN();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();

							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   
					   if("05".equals(s.substring(2, 4)) )
					   {
						   
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_5();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();

							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("06".equals(s.substring(2, 4)))
					   {
						  
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_6();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();

							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
							
							
						   }
					   }
					   if("07".equals(s.substring(2, 4)) )
					   {
						 
						   
						   Class<?> clazz = velemtemp.getClass();
						  Map<String, String> v =  x.getTcr_tc5_7();
						    
						   Iterator <Map.Entry<String, String>>  entry =  v.entrySet().iterator();
						   
						   while(entry.hasNext())
						   {
							  Entry<String,String> e = entry.next();
							  e.getKey();

							int a1 = Integer.parseInt(e.getValue().substring(0,e.getValue().indexOf(",")));
							int a2 = Integer.parseInt(e.getValue().substring(e.getValue().indexOf(",")+1,e.getValue().length()));
							String g = s.substring(a1-1, a2);
							//System.out.println(e.getKey()+"-"+g);
							 Field f1 = clazz.getField(e.getKey());
	                		  f1.setAccessible(true);
	                		  f1.set(velemtemp, g);
							
						   }
					   }

			   }
		   }
		
			   
			 
			   if("00".equals(s.substring(2,4))  && ("05".equals(s.substring(0,2)) || "06".equals(s.substring(0,2)) || "07".equals(s.substring(0,2)) ||"92".equals(s.substring(0,2)) ) )
				{
				   	return velemList.iterator();
				}else {
					
					return new LinkedList<VElements>().iterator();
				}
			   
			//   return alist.iterator();
	
	
	}
				 
		   });	
		   
		 
		   System.out.println("The End file reading"+new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()));
		   
		   System.out.println(flatMap.count());
		  
		   
		   
		   
		   //List<VElements> r = flatMap.collect();
		   
		//   Iterator<VElements> itr = r.iterator();
		   
		   System.out.println("The End file collect"+new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()));
		   
		    session=((AnnotationConfiguration) new AnnotationConfiguration() 
	                .configure()).buildSessionFactory().openSession(); 
	             
		    org.hibernate.Transaction t= session.beginTransaction(); 
		    
		    Criteria c = session.createCriteria(PMasterData.class);  
		    Criterion exp =  Restrictions.not(Restrictions.eq("exceptions", "NO"));   
		    Criterion complete = Restrictions.not(Restrictions.eq("complete", "Y")); 
		    Criterion exp1 = Restrictions.isNull("exceptions");
		    
		    LogicalExpression orExp =Restrictions.or(exp, complete);
		    LogicalExpression orExp1 =Restrictions.or(orExp, exp1);
		   
		   c.add(orExp1);
		   
		   
		  
		   
		   Iterator<PMasterData> itr= c.list().iterator();
		   
		   while(itr.hasNext())
		   {
			   String pid =  itr.next().getProcess_id();
			   Query del =session.createQuery("delete from PMasterData where process_id = :process_id");
			   del.setParameter("process_id", pid);
			   
			   del.executeUpdate();
			   
			   del =session.createQuery("delete from VElements where process_id = :process_id");
			   del.setParameter("process_id", pid);
			   
			   del.executeUpdate();
		   }

		   
		    
	               c = session.createCriteria(FileInfoDta.class);
	              
	              System.out.println("total count"+total_count);
	              System.out.println("total_amount"+total_amount);
	              Criterion count = Restrictions.eq("count_of_tran", total_count);
	              Criterion amt =Restrictions.eq("tot_amt", total_amount);
	              LogicalExpression andExp = Restrictions.and(count, amt);
	              c.add(andExp);
	              System.out.println("c.list().size()"+c.list().size());
	              
	             if(c.list().size()>0)
	             {
	            	 t.commit();
	            	 throw new Exception("File Already Processed ...");
	             
	             
	             }
	             
	             
	             Processing_SER.updatePMDta(pmdta);
	              
	              
		  // int io = 0;
		   
		   
		   System.out.println("The Start hib"+new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()));
		   
	
		   
		   
 flatMap.foreach((VoidFunction<VElements>) row ->
		 
 
		 save(row,session)
		   
				   );
		   
		   
		   FileInfoDta fData = new FileInfoDta();
		   fData.setFile_name("s");
		   fData.setCreation_date(file_date);
		   fData.setTot_amt(total_amount);
		   fData.setCount_of_tran(total_count);
		   fData.setProcess_id(pmdta.getProcess_id());
		   fData.setId(String.valueOf(Math.random()));
		   session.save(fData);
		   
		   
		   t.commit();
		   session.close();
		   
		   System.out.println("The End hib"+new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()));
		   
		 //  System.out.println("r::::::::"+r.size());
		   
		   System.out.println("The End"+new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()));
		   
		   
		   pmdta.setComplete("Y");
		   
		   pmdta.setExceptions("NO");
		   
		   pmdta.setEndtime(new Date());
		   
		   Processing_SER.updatePMDta(pmdta);
			
		  
		  
		  sc.close(); 
		  
		 
		  
	}
	private static void save(VElements row, Session session) {
		// TODO Auto-generated method stub
		
		 session.save(row);
		   if ( vcount % 100 == 0 ) { //20, same as the JDBC batch size
		        //flush a batch of inserts and release memory:
		        session.flush();
		        session.clear();
		    }
		vcount++;
		
		
	}
}

