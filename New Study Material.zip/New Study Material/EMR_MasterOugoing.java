package com.isg.execute;
import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.ExpressionEncoder;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Decimal;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import java.io.*;

import scala.Function1;
import scala.Function2;
import scala.Tuple2;
import scala.util.Random;

public class EMR_MasterOugoing {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String warehouseLocation = new File("spark-warehouse").getAbsolutePath();
		SparkSession sparkSession = SparkSession.builder().appName("MastOut").config("spark.default.parallelism", "40")
				.config("spark.sql.warehouse.dir", warehouseLocation)
				.enableHiveSupport()
				.getOrCreate();

		printMessage("args = " + args);
		String inFile = args[1];//"interchange.emr_app_switchacqtemp_testdata";
		String outFile =args[3];// "interchange.EMR_APP_VISA_FPOUTTEMP";
		String switchFile = args[2];//"'SWTCH.150919'";

		Class.forName("oracle.jdbc.driver.OracleDriver");
		Dataset<Row> CurencyDF = sparkSession.sql("SELECT JDT,MIDRATE,CURRENCY,BASE_CURR_CODE from EMR_APP_MAST_CURRENCYUPDATE_V2");
		Dataset<Row> IRDDF = sparkSession.sql("SELECT A.*,B.* FROM SYS_MAST_IRDIDS A, SYS_MAST_IRDTABLE B WHERE A.TXN_ID = B.TXN_ID;");
		Dataset<Row> fpMastDF = sparkSession.sql("SELECT * from EMR_MASTER_FPOUTTEMP");
		StructField[] fpMastOutschemaFields = {
				new StructField("PROCESS_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("LOG_DATETIME", DataTypes.TimestampType, true, Metadata.empty()),
				new StructField("RECORD_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ISS_INSTT_LOG_NET", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ISS_INSTT_FIID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_MEMBER_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("FILLER1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("RETAILER_INSTT_FIID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("RETAILER_GRP", DataTypes.StringType, true, Metadata.empty()),
				new StructField("RETAILER_RGN", DataTypes.StringType, true, Metadata.empty()),
				new StructField("RETAILER_ID1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PRDF_TERM_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SHIFT_NUM1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("BATCH_NUM1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_LOG_NET", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_INSTT_FIID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("OCCUR_TRAN_TIME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("RETCLR_TERM_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("INFO_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("RETAILER_ID2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CLERK_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("USER_DATA_FLAG", DataTypes.StringType, true, Metadata.empty()),
				new StructField("MSG_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SYS_MSG_STATUS", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIGINATOR1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("RESPONDER", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ISSUER", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SWITCH_ENTRY_TIME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AUTH_HOST_CONTACT_TIME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AUTH_HOST_RESP_TIME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("BEGIN_TRAN_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("BEGIN_TRAN_TIME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SWITCH_POST_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ACQ_ICHG_SETTL_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ISS_ICHG_SETTL_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_SEQ_NO", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PTDF_TERM_NAME_LOC", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PTDF_TERM_OWNER", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_CITY", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_STATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_COUNTRY_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("FILLER2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("FILLER3", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PROCESSOR_TIME_DIFF", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PTDF_TERM_ROUTE_NO", DataTypes.StringType, true, Metadata.empty()),
				new StructField("IDF_ISS_ROUTE_NO", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PTDF_TERM_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PTDF_POS_DEVICE_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("OPR_GRP_FOR_CRT_AUTH", DataTypes.StringType, true, Metadata.empty()),
				new StructField("OPR_ID_FOR_CRT_AUTH", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SIC_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIGINATOR2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("DESTINATION", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TC", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_TYPE1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ACCOUNT_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TRAN_CATEGORY", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_TYPE2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ACCOUNT_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SWITCH_RESP_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TOTAL_AMOUNT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ACTUAL_AMOUNT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_EXPIRY_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_TRACK2_INFO", DataTypes.StringType, true, Metadata.empty()),
				new StructField("FILLER4", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PRE_AUTH_SEQ_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_INVOICE_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIG_TERM_INVOICE_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AUTHORIZER", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AUTH_IND1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SHIFT_NUM2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("BATCH_NUM2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AUTH_APP_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("STD_APP_CODE_LEN", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ICHG_RESP", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PSEUDO_TERM_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("REFERRAL_TEL_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("DFT_CAPTURE_FLAG", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_CUT_OVER_MODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("RVRSL_ADJ_REASON", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CHRGBK_REASON", DataTypes.StringType, true, Metadata.empty()),
				new StructField("NUM_OF_CHRGBK", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TRAN_ORIGIN", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PAN_ENTRY_MODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AUTH_IND2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIG_CURR_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AUTH_CURR_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AUTH_CONV_RATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SETTL_CURR_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SETTL_CONV_RATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CONV_DATE_TIME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ACC_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AVAIL_BAL_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AVAIL_CRL_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("LEDG_BAL_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CR_LMT_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("AMT_ON_HOLD_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CR_BAL_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TOTAL_FLOAT_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CURR_FLOAT_IMP_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ADJ_IMP_SETTL_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PBF1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PBF2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PBF3", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PBF4", DataTypes.StringType, true, Metadata.empty()),
				new StructField("FRWD_INSTT_IDEN_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_ACC_IDEN_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_ISS_IDEN_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIG_MSG_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIG_TRAN_TIME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIG_TRAN_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIG_SEQ_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORIG_SW_POST_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("EXCP_RSN_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("NORM_CRT_TRAN_FLAG", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_BILL_ADDR", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_ZIP_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ADDR_VRFY_STAT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PIN_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PIN_TRIES", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PRE_AUTH_EXP_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PRE_AUTH_EXP_TIME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PRE_AUTH_HLDS_LVL", DataTypes.StringType, true, Metadata.empty()),
				new StructField("FILLER5", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PSTM_USR_DATA_INFO", DataTypes.StringType, true, Metadata.empty()),
				new StructField("FILLER6", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_RESP_SRC_RSN_CDE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_CRD_VRFY_FLG2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_ONLINE_LMT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_RETL_CLASS_CDE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_EMV_CAPABLE_OUTLET", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_RECUR_PMNT_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CH_USR_FLD1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_CVD_FLD", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_RESUBMIT_STAT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_RESUBMIT_CNT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_TERM_POSTAL_CDE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_ECOM_MOTO_FLAG", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_CMRCL_CARD_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_ADNL_DATA_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_CVD_FLD_PRESENT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_SAF_OR_FORCE_POST", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_AUTH_COLL_IND", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_FREE_PRN_FLG", DataTypes.StringType, true, Metadata.empty()),
				new StructField("C0_USER_FLD1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_BIT_MAP", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_USER_FLD1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_CRYPTO_INFO_DATA", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_TVR", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_ARQC", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_AMT_AUTH", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_AMT_OTHER", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_A1P", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_ATC", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_TERM_CRNCY_CDE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_TRAN_ENTRY_CDE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_TRAN_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_TRAN_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_UNPREDICT_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_ISS_APP_DATA_LEN", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B2_ISS_APP_DATA", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_BIT_MAP", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_TERM_SRL_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_EMV_TERM_CAP", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_USER_FLD1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_USER_FLD2", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_EMV_TERM_TYPE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_APPL_VER_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_CVM_RSLTS", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_DF_NAME_LGTH", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B3_NAME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_PT_SRV_ENTRY_MDE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_TERM_ENTRY_CAP", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_LAST_EMV_STAT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_DATA_SUSPECT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_APPL_PAN_SEQ_NUM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_DEV_INFO", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_RSN_ONL_CDE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_ARQC_VRFY", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B4_USER_FLD1", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B5_ISSATHDT_LGTH", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B5_ISSATHDT_ADD_DATA", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B5_ISSATHDT_RESP_CDE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B5_ISSATHDT_INFO", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B5_ISSATHDT_SND_CRD_BLK", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B5_ISSATHDT_SND_PUT_DT", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B6_ISS_SCR_DATA_LGTH", DataTypes.StringType, true, Metadata.empty()),
				new StructField("B6_ISS_SCR_DATA", DataTypes.StringType, true, Metadata.empty()),
				new StructField("BJ_DATA", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ERR_FLG_04", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ROUTING_GROUP_04", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CRD_VRFY_FLG_04", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CITY_EXT_04", DataTypes.StringType, true, Metadata.empty()),
				new StructField("COMPLETE_TRACK2_DATA_04", DataTypes.StringType, true, Metadata.empty()),
				new StructField("UAF_FLAG_04", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("MIPM_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("IS_DUP", DataTypes.StringType, true, Metadata.empty()),
				new StructField("EXCEPTIONS", DataTypes.StringType, true, Metadata.empty()),
				new StructField("FILE_NAME", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CHK_FLAG", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ENTRY_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CHECKER_DATE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("COMM", DataTypes.StringType, true, Metadata.empty()),
				new StructField("GEN_FLAG", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PRT_ACNT_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SERVICE_CODE", DataTypes.StringType, true, Metadata.empty()),
				new StructField("DE055", DataTypes.StringType, true, Metadata.empty()),
				new StructField("UTIL_FLAG", DataTypes.StringType, true, Metadata.empty()),
				new StructField("LOFO,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("BRANCH_CODE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ENVELOPE_NUMBER,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SCHEDULE_NUMBER", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ME_ZIP", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CURR_EXP,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("POI_AMOUNT,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("POI_CURR_CODE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("POI_CURR_EXP,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("OUT_FILE_CTRL", DataTypes.StringType, true, Metadata.empty()),
				new StructField("DE224861,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("GATEWAY_TYPE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("DEVICE_TYPE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TECH_TYPE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TRACE_ID,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PPOL,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TRANSIT_TRAN,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ORG_ID", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TXN_CAT,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TERM_COMPL_IND,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ctx_id,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("mtx_id,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PAY_FAC_ID,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("IND_SALE_ORG_ID,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_ID,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("PAY_FAC_NAME,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_NAME,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_STREET_ADDR,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_CITY,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_STATE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_COUNTRY_CDE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_POS_COUNTRY_CDE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_POS_POSTAL_CDE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SUB_MRCH_CAT_CDE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("ARN,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("REPROCESS_DATE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("SURCHARGE,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("TOT_COMM,", DataTypes.StringType, true, Metadata.empty()),
				new StructField("CARD_PROGRAM", DataTypes.StringType, true, Metadata.empty()),
				};
				StructType fpMastOutSchema = new StructType(fpMastOutschemaFields);
					// = = = = = = = = = = = = = = = Traverse using row iterator BEGIN = = = = = = = = = = = = = = = = = = = = = =
					Date jdt = new Date();
					java.sql.Date dt = new java.sql.Date(jdt.getTime());
					ExpressionEncoder<Row> encoder = RowEncoder.apply(fpMastOutSchema);
					Dataset<Row> fpMastOutDF = fpMastDF.repartition(38).flatMap( EMR_MasterOugoing::call,encoder);
					
	}
	
	
	public static Iterator<Row> call(Row record) throws Exception {
		
		String PROCESS_ID = record.getString(1);
		String   LOG_DATETIME = record.getString(2);
		String   RECORD_TYPE = record.getString(3);
		String   ISS_INSTT_LOG_NET = record.getString(4);
		String   ISS_INSTT_FIID = record.getString(5);
		String   CARD_NUM = record.getString(6);
		String   CARD_MEMBER_NUM = record.getString(7);
		String   FILLER1 = record.getString(8);
		String   RETAILER_INSTT_FIID = record.getString(9);
		String   RETAILER_GRP = record.getString(10);
		String   RETAILER_RGN = record.getString(11);
		String   RETAILER_ID1 = record.getString(12);
		String   PRDF_TERM_ID = record.getString(13);
		String   SHIFT_NUM1 = record.getString(14);
		String   BATCH_NUM1 = record.getString(15);
		String   TERM_LOG_NET = record.getString(16);
		String   TERM_INSTT_FIID = record.getString(17);
		String   TERM_ID = record.getString(18);
		String   OCCUR_TRAN_TIME = record.getString(19);
		String   RETCLR_TERM_ID = record.getString(20);
		String   INFO_TYPE = record.getString(21);
		String   RETAILER_ID2 = record.getString(22);
		String   CLERK_ID = record.getString(23);
		String   USER_DATA_FLAG = record.getString(24);
		String   MSG_TYPE = record.getString(25);
		String   SYS_MSG_STATUS = record.getString(26);
		String   ORIGINATOR1 = record.getString(27);
		String   RESPONDER = record.getString(28);
		String   ISSUER = record.getString(29);
		String   SWITCH_ENTRY_TIME = record.getString(30);
		String   AUTH_HOST_CONTACT_TIME = record.getString(31);
		String   AUTH_HOST_RESP_TIME = record.getString(32);
		String   BEGIN_TRAN_DATE = record.getString(33);
		String   BEGIN_TRAN_TIME = record.getString(34);
		String   SWITCH_POST_DATE = record.getString(35);
		String   ACQ_ICHG_SETTL_DATE = record.getString(36);
		String   ISS_ICHG_SETTL_DATE = record.getString(37);
		String   TERM_SEQ_NO = record.getString(38);
		String   PTDF_TERM_NAME_LOC = record.getString(39);
		String   PTDF_TERM_OWNER = record.getString(40);
		String   TERM_CITY = record.getString(41);
		String   TERM_STATE = record.getString(42);
		String   TERM_COUNTRY_CODE = record.getString(43);
		String   FILLER2 = record.getString(44);
		String   FILLER3 = record.getString(45);
		String   PROCESSOR_TIME_DIFF = record.getString(46);
		String   PTDF_TERM_ROUTE_NO = record.getString(47);
		String   IDF_ISS_ROUTE_NO = record.getString(48);
		String   PTDF_TERM_TYPE = record.getString(49);
		String   PTDF_POS_DEVICE_ID = record.getString(50);
		String   OPR_GRP_FOR_CRT_AUTH = record.getString(51);
		String   OPR_ID_FOR_CRT_AUTH = record.getString(52);
		String   SIC_CODE = record.getString(53);
		String   ORIGINATOR2 = record.getString(54);
		String   DESTINATION = record.getString(55);
		String   TC = record.getString(56);
		String   CARD_TYPE1 = record.getString(57);
		String   ACCOUNT_TYPE = record.getString(58);
		String   TRAN_CATEGORY = record.getString(59);
		String   CARD_TYPE2 = record.getString(60);
		String   ACCOUNT_NUM = record.getString(61);
		String   SWITCH_RESP_CODE = record.getString(62);
		String   TOTAL_AMOUNT = record.getString(63);
		String   ACTUAL_AMOUNT = record.getString(64);
		String   CARD_EXPIRY_DATE = record.getString(65);
		String   CARD_TRACK2_INFO = record.getString(66);
		String   FILLER4 = record.getString(67);
		String   PRE_AUTH_SEQ_NUM = record.getString(68);
		String   TERM_INVOICE_NUM = record.getString(69);
		String   ORIG_TERM_INVOICE_NUM = record.getString(70);
		String   AUTHORIZER = record.getString(71);
		String   AUTH_IND1 = record.getString(72);
		String   SHIFT_NUM2 = record.getString(73);
		String   BATCH_NUM2 = record.getString(74);
		String   AUTH_APP_CODE = record.getString(75);
		String   STD_APP_CODE_LEN = record.getString(76);
		String   ICHG_RESP = record.getString(77);
		String   PSEUDO_TERM_ID = record.getString(78);
		String   REFERRAL_TEL_NUM = record.getString(79);
		String   DFT_CAPTURE_FLAG = record.getString(80);
		String   TERM_CUT_OVER_MODE = record.getString(81);
		String   RVRSL_ADJ_REASON = record.getString(82);
		String   CHRGBK_REASON = record.getString(83);
		String   NUM_OF_CHRGBK = record.getString(84);
		String   TRAN_ORIGIN = record.getString(85);
		String   PAN_ENTRY_MODE = record.getString(86);
		String   AUTH_IND2 = record.getString(87);
		String   ORIG_CURR_CODE = record.getString(88);
		String   AUTH_CURR_CODE = record.getString(89);
		String   AUTH_CONV_RATE = record.getString(90);
		String   SETTL_CURR_CODE = record.getString(91);
		String   SETTL_CONV_RATE = record.getString(92);
		String   CONV_DATE_TIME = record.getString(93);
		String   ACC_IMP_IND = record.getString(94);
		String   AVAIL_BAL_IMP_IND = record.getString(95);
		String   AVAIL_CRL_IMP_IND = record.getString(96);
		String   LEDG_BAL_IMP_IND = record.getString(97);
		String   CR_LMT_IMP_IND = record.getString(98);
		String   AMT_ON_HOLD_IMP_IND = record.getString(99);
		String   CR_BAL_IMP_IND = record.getString(100);
		String   TOTAL_FLOAT_IMP_IND = record.getString(101);
		String   CURR_FLOAT_IMP_IND = record.getString(102);
		String   ADJ_IMP_SETTL_IND = record.getString(103);
		String   PBF1 = record.getString(104);
		String   PBF2 = record.getString(105);
		String   PBF3 = record.getString(106);
		String   PBF4 = record.getString(107);
		String   FRWD_INSTT_IDEN_NUM = record.getString(108);
		String   CARD_ACC_IDEN_NUM = record.getString(109);
		String   CARD_ISS_IDEN_NUM = record.getString(110);
		String   ORIG_MSG_TYPE = record.getString(111);
		String   ORIG_TRAN_TIME = record.getString(112);
		String   ORIG_TRAN_DATE = record.getString(113);
		String   ORIG_SEQ_NUM = record.getString(114);
		String   ORIG_SW_POST_DATE = record.getString(115);
		String   EXCP_RSN_CODE = record.getString(116);
		String   NORM_CRT_TRAN_FLAG = record.getString(117);
		String   CH_BILL_ADDR = record.getString(118);
		String   CH_ZIP_CODE = record.getString(119);
		String   ADDR_VRFY_STAT = record.getString(120);
		String   PIN_IND = record.getString(121);
		String   PIN_TRIES = record.getString(122);
		String   PRE_AUTH_EXP_DATE = record.getString(123);
		String   PRE_AUTH_EXP_TIME = record.getString(124);
		String   PRE_AUTH_HLDS_LVL = record.getString(125);
		String   FILLER5 = record.getString(126);
		String   PSTM_USR_DATA_INFO = record.getString(127);
		String   FILLER6 = record.getString(128);
		String   CH_RESP_SRC_RSN_CDE = record.getString(129);
		String   CH_CRD_VRFY_FLG2 = record.getString(130);
		String   CH_ONLINE_LMT = record.getString(131);
		String   CH_RETL_CLASS_CDE = record.getString(132);
		String   CH_EMV_CAPABLE_OUTLET = record.getString(133);
		String   CH_RECUR_PMNT_IND = record.getString(134);
		String   CH_USR_FLD1 = record.getString(135);
		String   C0_CVD_FLD = record.getString(136);
		String   C0_RESUBMIT_STAT = record.getString(137);
		String   C0_RESUBMIT_CNT = record.getString(138);
		String   C0_TERM_POSTAL_CDE = record.getString(139);
		String   C0_ECOM_MOTO_FLAG = record.getString(140);
		String   C0_CMRCL_CARD_TYPE = record.getString(141);
		String   C0_ADNL_DATA_IND = record.getString(142);
		String   C0_CVD_FLD_PRESENT = record.getString(143);
		String   C0_SAF_OR_FORCE_POST = record.getString(144);
		String   C0_AUTH_COLL_IND = record.getString(145);
		String   C0_FREE_PRN_FLG = record.getString(146);
		String   C0_USER_FLD1 = record.getString(147);
		String   B2_BIT_MAP = record.getString(148);
		String   B2_USER_FLD1 = record.getString(149);
		String   B2_CRYPTO_INFO_DATA = record.getString(150);
		String   B2_TVR = record.getString(151);
		String   B2_ARQC = record.getString(152);
		String   B2_AMT_AUTH = record.getString(153);
		String   B2_AMT_OTHER = record.getString(154);
		String   B2_A1P = record.getString(155);
		String   B2_ATC = record.getString(156);
		String   B2_TERM_CRNCY_CDE = record.getString(157);
		String   B2_TRAN_ENTRY_CDE = record.getString(158);
		String   B2_TRAN_DATE = record.getString(159);
		String   B2_TRAN_TYPE = record.getString(160);
		String   B2_UNPREDICT_NUM = record.getString(161);
		String   B2_ISS_APP_DATA_LEN = record.getString(162);
		String   B2_ISS_APP_DATA = record.getString(163);
		String   B3_BIT_MAP = record.getString(164);
		String   B3_TERM_SRL_NUM = record.getString(165);
		String   B3_EMV_TERM_CAP = record.getString(166);
		String   B3_USER_FLD1 = record.getString(167);
		String   B3_USER_FLD2 = record.getString(168);
		String   B3_EMV_TERM_TYPE = record.getString(169);
		String   B3_APPL_VER_NUM = record.getString(170);
		String   B3_CVM_RSLTS = record.getString(171);
		String   B3_DF_NAME_LGTH = record.getString(172);
		String   B3_NAME = record.getString(173);
		String   B4_PT_SRV_ENTRY_MDE = record.getString(174);
		String   B4_TERM_ENTRY_CAP = record.getString(175);
		String   B4_LAST_EMV_STAT = record.getString(176);
		String   B4_DATA_SUSPECT = record.getString(177);
		String   B4_APPL_PAN_SEQ_NUM = record.getString(178);
		String   B4_DEV_INFO = record.getString(179);
		String   B4_RSN_ONL_CDE = record.getString(180);
		String   B4_ARQC_VRFY = record.getString(181);
		String   B4_USER_FLD1 = record.getString(182);
		String   B5_ISSATHDT_LGTH = record.getString(183);
		String   B5_ISSATHDT_ADD_DATA = record.getString(184);
		String   B5_ISSATHDT_RESP_CDE = record.getString(185);
		String   B5_ISSATHDT_INFO = record.getString(186);
		String   B5_ISSATHDT_SND_CRD_BLK = record.getString(187);
		String   B5_ISSATHDT_SND_PUT_DT = record.getString(188);
		String   B6_ISS_SCR_DATA_LGTH = record.getString(189);
		String   B6_ISS_SCR_DATA = record.getString(190);
		String   BJ_DATA = record.getString(191);
		String   ERR_FLG_04 = record.getString(192);
		String   ROUTING_GROUP_04 = record.getString(193);
		String   CRD_VRFY_FLG_04 = record.getString(194);
		String   CITY_EXT_04 = record.getString(195);
		String   COMPLETE_TRACK2_DATA_04 = record.getString(196);
		String   UAF_FLAG_04 = record.getString(197);
		String   ID = record.getString(198);
		String   MIPM_ID = record.getString(199);
		String   IS_DUP = record.getString(200);
		String   EXCEPTIONS = record.getString(201);
		String   FILE_NAME = record.getString(202);
		String   CHK_FLAG = record.getString(203);
		String   ENTRY_DATE = record.getString(204);
		String   CHECKER_DATE = record.getString(205);
		String   COMM = record.getString(206);
		String   GEN_FLAG = record.getString(207);
		String   PRT_ACNT_ID = record.getString(208);
		String   SERVICE_CODE = record.getString(209);
		String   DE055 = record.getString(210);
		String   UTIL_FLAG = record.getString(211);
		String   LOFO= record.getString(212);
		String   BRANCH_CODE= record.getString(213);
		String   ENVELOPE_NUMBER= record.getString(214);
		String   SCHEDULE_NUMBER = record.getString(215);
		String   ME_ZIP = record.getString(216);
		String   CURR_EXP= record.getString(217);
		String   POI_AMOUNT= record.getString(218);
		String   POI_CURR_CODE= record.getString(219);
		String   POI_CURR_EXP= record.getString(220);
		String   OUT_FILE_CTRL = record.getString(221);
		String   DE224861= record.getString(222);
		String   GATEWAY_TYPE= record.getString(223);
		String   DEVICE_TYPE= record.getString(224);
		String   TECH_TYPE= record.getString(225);
		String   TRACE_ID= record.getString(226);
		String   PPOL= record.getString(227);
		String   TRANSIT_TRAN= record.getString(228);
		String   ORG_ID = record.getString(229);
		String   TXN_CAT= record.getString(230);
		String   TERM_COMPL_IND= record.getString(231);
		String   ctx_id= record.getString(232);
		String   mtx_id= record.getString(233);
		String   PAY_FAC_ID= record.getString(234);
		String   IND_SALE_ORG_ID= record.getString(235);
		String   SUB_MRCH_ID= record.getString(236);
		String   PAY_FAC_NAME= record.getString(237);
		String   SUB_MRCH_NAME= record.getString(238);
		String   SUB_MRCH_STREET_ADDR= record.getString(239);
		String   SUB_MRCH_CITY= record.getString(240);
		String   SUB_MRCH_STATE= record.getString(241);
		String   SUB_MRCH_COUNTRY_CDE= record.getString(242);
		String   SUB_MRCH_POS_COUNTRY_CDE= record.getString(243);
		String   SUB_MRCH_POS_POSTAL_CDE= record.getString(244);
		String   SUB_MRCH_CAT_CDE= record.getString(245);
		String   ARN= record.getString(246);
		String   REPROCESS_DATE= record.getString(247);
		String   SURCHARGE= record.getString(248);
		String   TOT_COMM= record.getString(249);
		String   CARD_PROGRAM = record.getString(250);
		String cardnumber_decrypted = record.getString(251);

		MSG_TYPE = (record.getString(25).contains("%#ARN%") && TC.equals("6"))?"420":MSG_TYPE;
		BEGIN_TRAN_DATE = new SimpleDateFormat("dd-MMM-yy").format(new SimpleDateFormat("MMddyy").parse(BEGIN_TRAN_DATE));
		TERM_COUNTRY_CODE = TERM_COUNTRY_CODE.substring(0, 3).toUpperCase();
		//CASE    WHEN (UTIL_FLAG='U'    AND LOFO       ='L')    THEN '4900'    ELSE SIC_CODE  END SIC_CODE 
		PTDF_TERM_NAME_LOC =  PTDF_TERM_NAME_LOC.substring(0,40)  ;
		PTDF_TERM_OWNER = PTDF_TERM_OWNER.substring(0,22) ;
			
		ArrayList<Row> newRows = new ArrayList<>();
		
		return newRows.iterator();
		
	}
	public static void printMessage(String message) {
		 System.out.println(message);
	}

}
