package com.isg.ext.config;
import java.util.LinkedHashMap;
import java.util.Map;
public class VisaCnTcrCn {
	
	Map<String, String> tcr_tc5_0 = null;
	Map<String, String> tcr_tc5_1 = null;
	Map<String, String> tcr_tc5_3 = null;
	//Map tcr_tc5_2 = null;
	
	public Map<String, String> getTcr_tc1_0()
	{
		tcr_tc5_0 = new LinkedHashMap<String,String>();
		
		tcr_tc5_0.put("tc","1,2");
		tcr_tc5_0.put("tcq","3,3");
		tcr_tc5_0.put("tcsn","4,4");
		tcr_tc5_0.put("an","5,20");
		tcr_tc5_0.put("ane","21,23");
		tcr_tc5_0.put("fli","24,24");
		tcr_tc5_0.put("cbr","25,25");
		tcr_tc5_0.put("pcas","26,26");
		tcr_tc5_0.put("arn","27,49");
		tcr_tc5_0.put("abid","50,57");
		tcr_tc5_0.put("purdte","58,61");
		tcr_tc5_0.put("damt","62,73");
		tcr_tc5_0.put("descurrcde","74,76");
		tcr_tc5_0.put("samt","77,88");
		tcr_tc5_0.put("sourcecurrcde","89,91");
		tcr_tc5_0.put("mename","92,116");
		tcr_tc5_0.put("mecity","117,129");
		tcr_tc5_0.put("mecntcde","130,132");
		tcr_tc5_0.put("mecatcode","133,136");
		tcr_tc5_0.put("mezipcde","137,141");
		tcr_tc5_0.put("mestate","142,144");
		tcr_tc5_0.put("reqpaystate","145,145");
		tcr_tc5_0.put("numpayform","146,147");
		tcr_tc5_0.put("uc","147,148");
		tcr_tc5_0.put("rc","148,149");
		tcr_tc5_0.put("settflag","149,150");
		tcr_tc5_0.put("ac1","150,151");
		tcr_tc5_0.put("ac","152,157");
		tcr_tc5_0.put("postermcap","157,158");
		tcr_tc5_0.put("intfeeInd","158,159");
		tcr_tc5_0.put("cardHoldIdmethod","159,160");
		tcr_tc5_0.put("collectionOnlyFlg","160,161");
		tcr_tc5_0.put("posentrymode","161,163");
		tcr_tc5_0.put("cpd","164,167");
		
		
		
		
		return tcr_tc5_0;
	}
	
	
	
	public Map<String, String> getTcr_tc5_0()
	{
		tcr_tc5_0 = new LinkedHashMap<String,String>();
		
		tcr_tc5_0.put("tc","1,2");
		tcr_tc5_0.put("tcq","3,3");
		tcr_tc5_0.put("tcsn","4,4");
		tcr_tc5_0.put("an","5,20");
		tcr_tc5_0.put("ane","21,23");
		tcr_tc5_0.put("fli","24,24");
		tcr_tc5_0.put("cbr","25,25");
		tcr_tc5_0.put("pcas","26,26");
		tcr_tc5_0.put("arn","27,49");
		tcr_tc5_0.put("abid","50,57");
		tcr_tc5_0.put("purdte","58,61");
		tcr_tc5_0.put("damt","62,73");
		tcr_tc5_0.put("descurrcde","74,76");
		tcr_tc5_0.put("samt","77,88");
		tcr_tc5_0.put("sourcecurrcde","89,91");
		tcr_tc5_0.put("mename","92,116");
		tcr_tc5_0.put("mecity","117,129");
		tcr_tc5_0.put("mecntcde","130,132");
		tcr_tc5_0.put("mecatcode","133,136");
		tcr_tc5_0.put("mezipcde","137,141");
		tcr_tc5_0.put("mestate","142,144");
		tcr_tc5_0.put("reqpaystate","145,145");
		tcr_tc5_0.put("numpayform","146,147");
		tcr_tc5_0.put("uc","147,148");
		tcr_tc5_0.put("rc","148,149");
		tcr_tc5_0.put("settflag","149,150");
		tcr_tc5_0.put("ac1","150,151");
		tcr_tc5_0.put("ac","152,157");
		tcr_tc5_0.put("postermcap","157,158");
		tcr_tc5_0.put("intfeeInd","158,159");
		tcr_tc5_0.put("cardHoldIdmethod","159,160");
		tcr_tc5_0.put("collectionOnlyFlg","160,161");
		tcr_tc5_0.put("posentrymode","161,163");
		tcr_tc5_0.put("cpd","164,167");
		
		
		
		
		return tcr_tc5_0;
	}
	
	public Map<String, String> getTcr_tc5_1()
	{
		tcr_tc5_1 = new LinkedHashMap<String,String>();
		
		tcr_tc5_1.put("tc","1,2");
		tcr_tc5_1.put("tcq","3,3");
		tcr_tc5_1.put("tcsn","4,4");
		tcr_tc5_1.put("bussforcde","5,5");
		tcr_tc5_1.put("chbkrefno","17,22");
		tcr_tc5_1.put("docind","23,23");
		tcr_tc5_1.put("memmsgtxt","24,73");
		tcr_tc5_1.put("spcndind","74,75");
		tcr_tc5_1.put("feeprgind","76,78");
		tcr_tc5_1.put("isschrge","79,79");
		tcr_tc5_1.put("crdaccpid","81,95");
		tcr_tc5_1.put("terminalid","96,103");
		tcr_tc5_1.put("nationremfee","104,115");
		tcr_tc5_1.put("mailind","116,116");
		tcr_tc5_1.put("specchbhind","117,117");
		tcr_tc5_1.put("intertranum","118,123");
		tcr_tc5_1.put("acctermind","124,124");
		tcr_tc5_1.put("perpaidcardind","126,126");
		tcr_tc5_1.put("avsrescode","127,127");
		tcr_tc5_1.put("authsourcecode","129,129");
		tcr_tc5_1.put("purchaseidenformat","129,129");
		tcr_tc5_1.put("accselection","130,130");
		tcr_tc5_1.put("installpaymentcount","131,132");
		tcr_tc5_1.put("purchaseind","133,157");
		tcr_tc5_1.put("cashback","158,166");
		tcr_tc5_1.put("chipcondcode","167,167");
		tcr_tc5_1.put("posenv","168,168");
		
		
		
		
		
		return tcr_tc5_1;
	}
	
	
	
	
	
	
	
	
	public Map<String, String> getTcr_tc5_3_AI()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("bussforcde","17,18");
		tcr_tc5_3.put("passnName","27,46");
		tcr_tc5_3.put("departdte","47,52");
		tcr_tc5_3.put("origcity","53,55");
		tcr_tc5_3.put("tripleg1","56,62");
		tcr_tc5_3.put("tripleg2","63,69");
		tcr_tc5_3.put("tripleg3","70,76");
		tcr_tc5_3.put("tripleg4","77,83");
		tcr_tc5_3.put("travelagencycode","84,91");
		tcr_tc5_3.put("travelagencyname","92,116");
		tcr_tc5_3.put("farebasiccode1","117,117");
		tcr_tc5_3.put("farebasiccode2","118,123");
		tcr_tc5_3.put("farebasiccode3","124,129");
		tcr_tc5_3.put("farebasiccode4","130,135");
		tcr_tc5_3.put("compresvsystem","136,141");
		tcr_tc5_3.put("flightno1","142,145");
		tcr_tc5_3.put("flightno2","146,150");
		tcr_tc5_3.put("flightno3","151,155");
		tcr_tc5_3.put("flightno4","156,160");
		tcr_tc5_3.put("creditrsnind","161,165");
		tcr_tc5_3.put("ticketchgind","166,166");
		
		return tcr_tc5_3;
	}	
	
	public Map<String, String> getTcr_tc5_3_AN()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("bussforcde","17,18");
		tcr_tc5_3.put("atdn","19,33");
		tcr_tc5_3.put("asc1","34,37");
		tcr_tc5_3.put("assc1","38,41");
		tcr_tc5_3.put("asc2","42,45");
		tcr_tc5_3.put("assc2","46,49");
		tcr_tc5_3.put("asc3","50,53");
		tcr_tc5_3.put("assc3","54,57");
		tcr_tc5_3.put("asc4","58,61");
		tcr_tc5_3.put("assc4","62,65");
		tcr_tc5_3.put("passnme","66,85");
		tcr_tc5_3.put("aiicwtn","86,100");
		tcr_tc5_3.put("acri","101,101");
		
		
		return tcr_tc5_3;
	}
	
	
	
	public Map<String, String> getTcr_tc5_3_LG()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("bussforcde","17,18");
		tcr_tc5_3.put("lnsi","27,27");
		tcr_tc5_3.put("ulec","28,33");
		tcr_tc5_3.put("ulcid","38,43");
		tcr_tc5_3.put("udrr","44,55");
		tcr_tc5_3.put("utt","56,67");
		tcr_tc5_3.put("upe","68,79");
		tcr_tc5_3.put("ufc","80,91");
		tcr_tc5_3.put("ufca","92,103");
		tcr_tc5_3.put("urn","104,105");
		tcr_tc5_3.put("utrt","106,117");
		
		
		
		
		return tcr_tc5_3;
	}
	
	public Map<String, String> getTcr_tc5_3_CA()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("bussforcde","17,18");
		tcr_tc5_3.put("dr","27,27");
		tcr_tc5_3.put("crnsi","28,33");
		tcr_tc5_3.put("crcid","38,43");
		tcr_tc5_3.put("drr","44,55");
		tcr_tc5_3.put("wrr","56,67");
		tcr_tc5_3.put("ic","68,79");
		tcr_tc5_3.put("fc","80,91");
		tcr_tc5_3.put("ccc","92,93");
		tcr_tc5_3.put("owdoc","94,105");
		tcr_tc5_3.put("rentername","106,145");
	
		
		
		
		return tcr_tc5_3;
	}
	
	
	
	
	public Map<String, String> getTcr_tc5_3_FL()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("bussforcde","17,18");
		tcr_tc5_3.put("eft","23,26");
		tcr_tc5_3.put("top","27,27");
		tcr_tc5_3.put("ft","28,29");
		tcr_tc5_3.put("uom","30,30");
		tcr_tc5_3.put("uq","31,42");
		tcr_tc5_3.put("uuc","43,54");
		tcr_tc5_3.put("ugnp","55,66");
		tcr_tc5_3.put("unnp","67,78");
		tcr_tc5_3.put("ordg","79,90");
		tcr_tc5_3.put("vtr","91,102");
		tcr_tc5_3.put("mft","103,109");
		tcr_tc5_3.put("pq","110,113");
		tcr_tc5_3.put("mnt","114,125");
		tcr_tc5_3.put("pq","126,131");
		tcr_tc5_3.put("mnt","138,149");
		tcr_tc5_3.put("servicetyp","150,150");
		tcr_tc5_3.put("mftes","151,151");
		tcr_tc5_3.put("mntes","152,152");
		
		
		return tcr_tc5_3;
	}
	

	
	public Map<String, String> getTcr_tc5_3_LD()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("bussforcde","17,18");
		tcr_tc5_3.put("ctit","19,22");
		tcr_tc5_3.put("cti","23,37");
		tcr_tc5_3.put("ai","38,39");
		tcr_tc5_3.put("lt","41,60");
		tcr_tc5_3.put("mgi","61,66");
		
		return tcr_tc5_3;
		
	}
	
	
	
	public Map<String, String> getTcr_tc5_3_CR()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("ffi","16,16");
		tcr_tc5_3.put("bussforcde","17,18");
		tcr_tc5_3.put("baid","19,20");
		tcr_tc5_3.put("sof","21,21");
		tcr_tc5_3.put("prrc","22,23");
		tcr_tc5_3.put("srn","24,39");
		tcr_tc5_3.put("san","40,73");
		tcr_tc5_3.put("sn","74,103");
		tcr_tc5_3.put("saddr","104,138");
		tcr_tc5_3.put("scity","139,163");
		tcr_tc5_3.put("sstate","164,165");
		tcr_tc5_3.put("scntry","166,168");
		
		
		
		return tcr_tc5_3;
	
	}
	
	
	
	public Map<String, String> getTcr_tc5_4_SP()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("bussforcde","15,16");
		tcr_tc5_3.put("nic","17,20");
		tcr_tc5_3.put("ci","21,45");
		tcr_tc5_3.put("api","46,46");
		tcr_tc5_3.put("rc","47,50");
		tcr_tc5_3.put("sa","51,58");
		tcr_tc5_3.put("scdi","59,60");
		tcr_tc5_3.put("pt","77,78");
		tcr_tc5_3.put("pc","79,103");
		tcr_tc5_3.put("sacbc","104,111");
		return tcr_tc5_3;
		
		
	}
	
	
	
	
	
	public Map<String, String> getTcr_tc5_4_PD()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("bussforcde","15,16");
		tcr_tc5_3.put("pt","17,18");
		tcr_tc5_3.put("pc","19,43");
	
		return tcr_tc5_3;
		
		
	}
	
	
/*	1�2 2 UN Transaction Code
	3 1 UN Transaction Code Qualifier
	4 1 UN Transaction Component Sequence Number
	5�19 15 UN Transaction Identifier
	20�31 12 UN Authorized Amount
	32�34 3 AN Authorization Currency Code
	35�36 2 AN Authorization Response Code
	37�40 4 AN Validation Code
	41 1 AN Excluded Transaction Identifier Reason
	42 1 AN CRS Processing Code
	43�44 2 AN Chargeback Rights Indicator
	45�46 2 UN Multiple Clearing Sequence Number
	47�48 2 UN Multiple Clearing Sequence Count
	49 1 AN Market-Specific Authorization Data Indicator
	50�61 12 UN Total Authorized Amount
	62 1 AN Information Indicator
	63�76 14 AN Merchant Telephone Number
	77 1 AN Additional Data Indicator
	78�79 2 AN Merchant Volume Indicator
	80�81 2 AN Electronic Commerce Goods Indicator
	82�91 10 AN Merchant Verification Value
	92�106 15 UN Interchange Fee Amount
	107 1 AN Interchange Fee Sign
	108�115 8 UN Source Currency to Base Currency Exchange Rate
	116�123 8 UN Base Currency to Destination Currency Exchange Rate
	124�135 12 UN Optional Issuer ISA Amount
	136�137 2 AN Product ID
	138�143 6 AN Program ID
	144 1 AN Dynamic Currency Conversion (DCC) Indicator
	145�148 4 AN Account Type Identification
	149 1 AN Spend Qualified Indicator
	150�165 16 UN PAN Token
	Format: AN = Alphanumeric, DX = Display Hexadecimal, N = Numeric, UN = Unpacked Numeric
	05-110 Visa Confidential BASE II Clearing Interchange Formats, TC 01 to TC 48 18 Apr 2015
	TCR 5 TC 05
	Draft Data Record Layout (continued)
	Position
	Field
	Length Format Contents
	166�167 2 AN Reserved
	168 1 AN CVV2 Result Code
	*/
	
	public Map<String, String> getTcr_tc5_5()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("tranidentifier","5,19");
		tcr_tc5_3.put("authamt","20,31");
		tcr_tc5_3.put("authcurrcde","32,34");
		tcr_tc5_3.put("authrescde","35,36");
		tcr_tc5_3.put("validatiocde","37,40");
		tcr_tc5_3.put("exctranidnrsn","41,41");
		tcr_tc5_3.put("crsprocccde","42,42");
		tcr_tc5_3.put("chbkrgtind","43,44");
		tcr_tc5_3.put("mulcleseqnum","45,46");
		tcr_tc5_3.put("mulcleseqcnt","47,48");
		tcr_tc5_3.put("marspecathdataind","49,49");
		tcr_tc5_3.put("totauthamt","50,61");
		tcr_tc5_3.put("infind","62,62");
		tcr_tc5_3.put("mertelnum","63,76");
		tcr_tc5_3.put("adi","77,77");
		tcr_tc5_3.put("mervolind","78,79");
		tcr_tc5_3.put("elcommgoodsind","80,81");
		tcr_tc5_3.put("merchvervalue","82,91");
		tcr_tc5_3.put("intfeeamt","92,106");
		tcr_tc5_3.put("intfeesign","107,107");
		tcr_tc5_3.put("srccurrbasecurrexcrte","108,115");
		tcr_tc5_3.put("basecurrdestcurrexcrte","116,123");
		tcr_tc5_3.put("oiia","124,135");
		tcr_tc5_3.put("prodid","136,137");
		tcr_tc5_3.put("progid","138,143");
		tcr_tc5_3.put("dccind","144,144");
		tcr_tc5_3.put("acctypid","41,41");
		tcr_tc5_3.put("spenquind","41,41");
		//tcr_tc5_3.put("an","41,41");
		
		
		return tcr_tc5_3;
	}
	
	
	
	/*
	 * 
	 * 1�2 2 UN Transaction Code
3 1 UN Transaction Code Qualifier
4 1 UN Transaction Component Sequence Number
5�16 12 UN Local Tax
17 1 UN Local Tax Included
18�29 12 UN National Tax
30 1 UN National Tax Included
31�50 20 AN Merchant VAT Registration/Single Business Reference Number
51�63 13 AN Customer VAT Registration Number
64�75 12 AN Reserved
76�79 4 AN Summary Commodity Code
80�91 12 UN Other Tax
92�106 15 AN Message Identifier
107�110 4 UN Time of Purchase
111�127 17 AN Customer Code/Customer Reference Identifier (CRI)
128�129 2 AN Non-Fuel Product Code 1
130�131 2 AN Non-Fuel Product Code 2
132�133 2 AN Non-Fuel Product Code 3
134�135 2 AN Non-Fuel Product Code 4
136�137 2 AN Non-Fuel Product Code 5
138�139 2 AN Non-Fuel Product Code 6
140�141 2 AN Non-Fuel Product Code 7
142�143 2 AN Non-Fuel Product Code 8
144�154 11 AN Merchant Postal Code
155�168 14 AN Reserved
Format: AN = Alphanumeric, DX = Display Hexadecimal, N = Numeric,
	 */
	
	public Map<String, String> getTcr_tc5_6()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("unlcltx","5,16");
		tcr_tc5_3.put("unlcltxinc","17,17");
		tcr_tc5_3.put("unnattx","18,29");
		tcr_tc5_3.put("unnattxinc","30,30");
		tcr_tc5_3.put("mvrbrn","31,50");
		tcr_tc5_3.put("crn","51,63");
		tcr_tc5_3.put("scc","76,79");
		tcr_tc5_3.put("othtx","80,91");
		tcr_tc5_3.put("msgind","92,106");
		tcr_tc5_3.put("top","107,110");
		tcr_tc5_3.put("ccri","11,127");
		tcr_tc5_3.put("nfpc1","128,129");
		tcr_tc5_3.put("nfpc2","130,131");
		tcr_tc5_3.put("nfpc3","132,133");
		tcr_tc5_3.put("nfpc4","134,135");
		tcr_tc5_3.put("nfpc5","136,137");
		tcr_tc5_3.put("nfpc6","138,139");
		tcr_tc5_3.put("nfpc7","140,141");
		tcr_tc5_3.put("nfpc8","142,143");
		tcr_tc5_3.put("mpc","144,154");
		
		
		return tcr_tc5_3;
	}
	
	
	
	/*
	 1�2 2 UN Transaction Code
3 1 UN Transaction Code Qualifier
4 1 UN Transaction Component Sequence Number
5�6 2 AN Transaction Type
7�9 3 UN Card Sequence Number
10�15 6 UN Terminal Transaction Date
16�21 6 DX Terminal Capability Profile
22�24 3 UN Terminal Country Code
25�32 8 AN Terminal Serial Number
33�40 8 DX Unpredictable Number
41�44 4 DX Application Transaction Counter
45�48 4 DX Application Interchange Profile
49�64 16 DX Cryptogram
65�66 2 DX Issuer Application Data, Byte 2
67�68 2 DX Issuer Application Data, Byte 3
69�78 10 DX Terminal Verification Results
79�86 8 DX Issuer Application Data, Byte 4�7
87�98 12 UN Cryptogram Amount
99�100 2 DX Issuer Application Data, Byte 8
101�116 16 DX Issuer Application Data, Byte 9�16
117�118 2 DX Issuer Application Data, Byte 1
119�120 2 DX Issuer Application Data, Byte 17
121�150 30 DX Issuer Application Data, Byte 18�32
151�158 8 DX Form Factor Indicator
159�168 10 DX Issuer Script 1 Results
	 
	 
	 
	 */
	public Map<String, String> getTcr_tc5_7()
	{
		tcr_tc5_3 = new LinkedHashMap<String,String>();
		tcr_tc5_3.put("tc","1,2");
		tcr_tc5_3.put("tcq","3,3");
		tcr_tc5_3.put("tcsn","4,4");
		tcr_tc5_3.put("txntyp","5,6");
		tcr_tc5_3.put("crdseqnum","7,9");
		tcr_tc5_3.put("trmtrndte","10,15");
		tcr_tc5_3.put("trmcapprf","16,21");
		tcr_tc5_3.put("trmcntcde","22,24");
		tcr_tc5_3.put("trmsernum","25,32");
		tcr_tc5_3.put("unprenum","33,40");
		tcr_tc5_3.put("apptrancnt","41,44");
		tcr_tc5_3.put("appintchgcnt","45,48");
		tcr_tc5_3.put("crypto","49,64");
		tcr_tc5_3.put("issappdata1","65,66");
		tcr_tc5_3.put("issappdata2","67,68");
		tcr_tc5_3.put("termverres","69,78");
		tcr_tc5_3.put("issappdata3","79,86");
		tcr_tc5_3.put("cryptamt","87,98");
		tcr_tc5_3.put("issappdata4","99,100");
		tcr_tc5_3.put("issappdata5","101,116");
		tcr_tc5_3.put("issappdata6","117,118");
		tcr_tc5_3.put("issappdata7","119,120");
		tcr_tc5_3.put("issappdata8","121,150");
		tcr_tc5_3.put("formfactor","151,158");
		return tcr_tc5_3;
	}
	}
	

